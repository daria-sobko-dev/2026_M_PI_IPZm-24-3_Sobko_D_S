# WP Security DSS — Система підтримки прийняття рішень

**Магістерська науково-дослідницька робота**

- **Автор:** Собко Дарія Сергіївна
- **Спеціальність:** 121 «Інженерія програмного забезпечення», магістр
- **Група:** ІПЗм-24-3
- **Університет:** Харківський національний університет радіоелектроніки (ХНУРЕ)
- **Кафедра:** Програмної інженерії
- **Науковий керівник:** к.т.н., доц. Грудзо І.В.
- **Рік захисту:** 2026

---

## 📋 Опис

**WP Security DSS** — це WordPress-плагін, який реалізує систему підтримки прийняття рішень (DSS, Decision Support System) для вибору оптимального плагіну безпеки під конкретні потреби e-commerce сайту.

Плагін базується на результатах експериментального дослідження 5 провідних плагінів безпеки WordPress:
1. **Wordfence Security** 8.2.1 (Free)
2. **Sucuri Security** 2.7.2 (Free)
3. **Kadence Security** 10.0.1 (Free)
4. **WP Cerber Security** 9.7.3 (Free)
5. **MalCare Security** 6.44 (Free)

Дослідження проведено на тестовому стенді WooCommerce магазину з 12 умисно встановленими уразливими плагінами (CVE 2019–2024) у 4-х класах атак: XSS, SQLi, RCE, Broken Access Control.

---

## 🎯 Функціонал плагіну

### 1. Dashboard
Огляд всіх 5 протестованих плагінів безпеки з ключовими метриками: **Recall** (виявлення CVE) та **Block Rate** (захист від активних атак). Автоматичний детектор: показує, які з 5 плагінів встановлені на поточному сайті та які з 12 уразливих плагінів присутні (для самотестування).

### 2. Порівняння
Інтерактивні графіки (Chart.js):
- Барна діаграма Recall vs Block Rate
- Пелюсткова (Radar) діаграма за 4 вимірами
- Scatter Парето-фронт (продуктивність × захист)

### 3. DSS Рекомендації
4 слайдери ваг для пріоритетів користувача:
- Виявлення уразливостей (Recall)
- Активний захист (Block Rate)
- Продуктивність (низьке навантаження CPU/RAM)
- Можливість офлайн-роботи

Інтегральний рейтинг розраховується за формулою зваженої суми. Топ-3 рекомендації виділяються золотим, срібним і бронзовим кольором.

### 4. Майстер тестування
Покроковий wizard для додавання нових плагінів безпеки (наприклад, якщо вийде нова версія Wordfence або з'явиться новий плагін). Користувач проходить стандартизовану процедуру:
- 12 пасивних перевірок CVE (чекбокси)
- 6 активних атак (Block / Pass / Warn)
- 4 метрики продуктивності (CPU base/load, RAM base/load)

Результати автоматично зберігаються в БД сайту, рейтинги перераховуються.

### 5. База результатів
Повна матриця всіх результатів експерименту (5 плагінів × 12 уразливостей + 5 × 6 атак + продуктивність).

### 6. Налаштування
Управління плагіном, експорт/імпорт даних у JSON.

---

## 🚀 Встановлення

1. Завантажити архів `wp-security-dss.zip`.
2. WordPress адмінка → **Плагіни → Додати новий → Завантажити плагін**.
3. Обрати ZIP-файл → **Встановити зараз** → **Активувати**.
4. Після активації плагін автоматично:
   - Створить 5 таблиць у БД (`wp_wpdss_plugins`, `wp_wpdss_vulnerabilities`, `wp_wpdss_scan_results`, `wp_wpdss_attack_results`, `wp_wpdss_performance`).
   - Наповнить таблиці експериментальними даними дослідження.
5. У лівому меню адмінки з'явиться пункт **🛡 Security DSS**.

---

## 🛠 Технічний стек

- **Backend:** PHP 7.4+, WordPress 6.0+
- **БД:** MySQL/MariaDB (5 таблиць)
- **Frontend:** Vanilla JS + jQuery (вбудований у WP)
- **Графіки:** Chart.js 4.4.0 (через CDN)
- **AJAX:** WordPress AJAX API (admin-ajax.php)
- **Стилі:** Власна CSS-система у стилі Wordfence Dashboard
- **i18n:** WordPress Translation API, домен `wp-security-dss`

---

## 📐 Архітектура

```
wp-security-dss/
├── wp-security-dss.php                 # Головний файл плагіну (entry point)
├── includes/
│   ├── class-dss-database.php          # Робота з БД, schema, seed-дані
│   ├── class-dss-detector.php          # Автодетект встановлених плагінів
│   ├── class-dss-calculator.php        # Формули Recall, Precision, F1, DSS Score
│   ├── class-dss-recommendation.php    # DSS-движок ранжування
│   └── class-dss-admin.php             # Реєстрація меню, AJAX, enqueue
├── admin/views/
│   ├── dashboard.php
│   ├── comparison.php
│   ├── dss-recommendations.php
│   ├── test-wizard.php
│   ├── results-database.php
│   └── settings.php
├── assets/
│   ├── css/admin-style.css
│   └── js/admin.js
├── data/
│   └── experimental-data.json          # Експорт результатів експерименту
├── languages/
│   ├── wp-security-dss-uk_UA.po        # Український переклад
│   └── wp-security-dss.pot             # Шаблон для перекладів
└── README.md
```

---

## 📊 Формули DSS

### Recall (повнота виявлення)

```
Recall = TP / (TP + FN) × 100%
```
де `TP` — true positives (правильно виявлені уразливості з вибірки), `FN` — false negatives (пропущені).

### Block Rate (відсоток заблокованих атак)

```
Block Rate = (кількість Block) / 6 × 100%
```

### Performance Score

```
Perf Score = 100 - normalize(CPU_load - CPU_base, RAM_load - RAM_base)
```

### DSS Score (інтегральна оцінка)

```
DSS = w_recall * Recall_norm
    + w_block  * BlockRate_norm
    + w_perf   * Perf_norm
    + w_offline * OfflineCapable
```

де `w_*` — нормалізовані ваги пріоритетів користувача (∑w = 1).

---

## 🔬 Експериментальна частина

Результати збережено у файлі `data/experimental-data.json`. Підсумок:

| Плагін | Recall | Block Rate | Архітектура |
|--------|--------|------------|-------------|
| A1 Wordfence       | 100% | 50% | Local CVE DB |
| A2 Sucuri Free     | 0%   | 0%  | Integrity Check only |
| A3 Kadence Security | 100% | ~33% | Patchstack Cloud API |
| A4 WP Cerber Free  | 0%   | TBD | Integrity Scanner |
| A5 MalCare         | 100% | TBD | AWS Cloud Scanner |

**Ключовий висновок:** бінарний розподіл за ефективністю CVE-сканування — 3 плагіни досягли 100% Recall через різні технології; 2 плагіни показали 0%, обмежуючись перевіркою цілісності файлів WordPress core.

---

## 📝 Ліцензія

GPL v2 або новіша. Плагін розроблено в академічних цілях.

---

## 📞 Контакти

- **Email автора:** cinderellka777@gmail.com
- **Університет:** [nure.ua](https://nure.ua)

---

*Цей плагін є частиною магістерської роботи на тему «Дослідження ефективності плагінів безпеки WordPress для e-commerce сайтів».*
