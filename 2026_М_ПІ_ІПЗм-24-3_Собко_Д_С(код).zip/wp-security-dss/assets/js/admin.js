/**
 * WP Security DSS — Admin JavaScript
 * Логіка DSS-движка, графіків та майстра тестування
 *
 * @package WP_Security_DSS
 * @author  Собко Дарія (ХНУРЕ, ІПЗм-24-3)
 */

(function ($) {
    'use strict';

    /* ==========================================================================
       Утиліти
       ========================================================================== */

    var WPDSSUtils = {
        formatPercent: function (value) {
            return parseFloat(value).toFixed(1) + '%';
        },
        getClassByValue: function (value) {
            if (value >= 70) return 'metric-high';
            if (value >= 30) return 'metric-med';
            return 'metric-low';
        }
    };

    /* ==========================================================================
       DSS-двигун (клієнтська частина)
       ========================================================================== */

    var WPDSSEngine = {
        /**
         * Розрахувати рейтинг плагінів за вагами користувача
         * weights: { recall, block, perf, offline }
         * plugins: масив об'єктів з метриками
         */
        rankPlugins: function (plugins, weights) {
            var sumWeights = weights.recall + weights.block + weights.perf + weights.offline;
            if (sumWeights === 0) return plugins.map(function (p) {
                return $.extend({}, p, { score: 0, rank: 0 });
            });

            // Нормалізуємо ваги, щоб у сумі давали 1
            var w = {
                recall:  weights.recall  / sumWeights,
                block:   weights.block   / sumWeights,
                perf:    weights.perf    / sumWeights,
                offline: weights.offline / sumWeights
            };

            var ranked = plugins.map(function (p) {
                var score =
                    (p.recall      / 100) * w.recall  +
                    (p.block_rate  / 100) * w.block   +
                    (p.perf_score  / 100) * w.perf    +
                    (p.offline_capable ? 1 : 0) * w.offline;
                return $.extend({}, p, { score: Math.round(score * 1000) / 10 });
            });

            ranked.sort(function (a, b) { return b.score - a.score; });
            ranked.forEach(function (p, i) { p.rank = i + 1; });

            return ranked;
        }
    };

    /* ==========================================================================
       Графіки (Chart.js)
       ========================================================================== */

    var WPDSSCharts = {
        instances: {},

        /**
         * Барна діаграма Recall vs Block Rate
         */
        renderRecallBlockBar: function (canvasId, plugins) {
            var ctx = document.getElementById(canvasId);
            if (!ctx) return;

            if (this.instances[canvasId]) {
                this.instances[canvasId].destroy();
            }

            this.instances[canvasId] = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: plugins.map(function (p) { return p.code + ' ' + p.name; }),
                    datasets: [
                        {
                            label: 'Recall (%)',
                            data: plugins.map(function (p) { return p.recall; }),
                            backgroundColor: '#2271b1',
                            borderRadius: 4
                        },
                        {
                            label: 'Block Rate (%)',
                            data: plugins.map(function (p) { return p.block_rate; }),
                            backgroundColor: '#46b450',
                            borderRadius: 4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: { callback: function (v) { return v + '%'; } }
                        }
                    },
                    plugins: {
                        legend: { position: 'top' },
                        tooltip: {
                            callbacks: {
                                label: function (ctx) {
                                    return ctx.dataset.label + ': ' + ctx.parsed.y + '%';
                                }
                            }
                        }
                    }
                }
            });
        },

        /**
         * Radar (пелюсткова) діаграма — всі 4 виміри
         */
        renderRadar: function (canvasId, plugins) {
            var ctx = document.getElementById(canvasId);
            if (!ctx) return;

            if (this.instances[canvasId]) {
                this.instances[canvasId].destroy();
            }

            var palette = ['#2271b1', '#dc3232', '#46b450', '#ffb900', '#00a0d2'];

            var datasets = plugins.map(function (p, i) {
                var color = p.color || palette[i % palette.length];
                return {
                    label: p.code + ' ' + p.name,
                    data: [
                        p.recall,
                        p.block_rate,
                        p.perf_score,
                        p.offline_capable ? 100 : 0
                    ],
                    borderColor: color,
                    backgroundColor: color + '33',
                    pointBackgroundColor: color,
                    borderWidth: 2
                };
            });

            this.instances[canvasId] = new Chart(ctx, {
                type: 'radar',
                data: {
                    labels: ['Recall', 'Block Rate', 'Продуктивність', 'Офлайн'],
                    datasets: datasets
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        r: {
                            min: 0,
                            max: 100,
                            ticks: { stepSize: 25 }
                        }
                    }
                }
            });
        },

        /**
         * Scatter — Парето-фронт (продуктивність × захист)
         */
        renderPareto: function (canvasId, plugins) {
            var ctx = document.getElementById(canvasId);
            if (!ctx) return;

            if (this.instances[canvasId]) {
                this.instances[canvasId].destroy();
            }

            var datasets = plugins.map(function (p) {
                return {
                    label: p.code + ' ' + p.name,
                    data: [{
                        x: p.perf_score,        // вісь X — продуктивність
                        y: (p.recall + p.block_rate) / 2  // вісь Y — середній захист
                    }],
                    backgroundColor: p.color || '#2271b1',
                    pointRadius: 12,
                    pointHoverRadius: 16
                };
            });

            this.instances[canvasId] = new Chart(ctx, {
                type: 'scatter',
                data: { datasets: datasets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            title: { display: true, text: 'Продуктивність →' },
                            min: 0, max: 100
                        },
                        y: {
                            title: { display: true, text: 'Захист (Recall+Block)/2 →' },
                            min: 0, max: 100
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function (ctx) {
                                    return ctx.dataset.label + ': Продукт. ' + ctx.parsed.x +
                                           ', Захист ' + ctx.parsed.y.toFixed(1) + '%';
                                }
                            }
                        }
                    }
                }
            });
        }
    };

    /* ==========================================================================
       Майстер тестування (Test Wizard) — навігація кроків
       ========================================================================== */

    var WPDSSWizard = {
        currentStep: 1,
        totalSteps: 4,

        init: function () {
            var self = this;

            $(document).on('click', '.wpdss-wizard-next', function (e) {
                e.preventDefault();
                self.next();
            });
            $(document).on('click', '.wpdss-wizard-prev', function (e) {
                e.preventDefault();
                self.prev();
            });

            $(document).on('click', '.wpdss-checklist-item', function () {
                var $item = $(this);
                var $checkbox = $item.find('input[type="checkbox"]');
                $checkbox.prop('checked', !$checkbox.prop('checked'));
                $item.toggleClass('checked', $checkbox.prop('checked'));
            });

            $(document).on('click', '.wpdss-wizard-save', function (e) {
                e.preventDefault();
                self.save();
            });

            this.show(1);
        },

        show: function (step) {
            this.currentStep = step;
            $('.wpdss-wizard-step-content').hide();
            $('.wpdss-wizard-step-content[data-step="' + step + '"]').show();

            $('.wpdss-wizard-step').each(function () {
                var n = parseInt($(this).data('step'), 10);
                $(this).removeClass('active done');
                if (n < step) $(this).addClass('done');
                if (n === step) $(this).addClass('active');
            });
        },

        next: function () {
            if (this.currentStep < this.totalSteps) {
                this.show(this.currentStep + 1);
            }
        },

        prev: function () {
            if (this.currentStep > 1) {
                this.show(this.currentStep - 1);
            }
        },

        save: function () {
            var data = {
                action: 'wpdss_save_test',
                nonce: wpdssData.nonce,
                plugin_code:         $('#wpdss-new-plugin-code').val(),
                plugin_name:         $('#wpdss-new-plugin-name').val(),
                plugin_version:      $('#wpdss-new-plugin-version').val(),
                plugin_architecture: $('#wpdss-new-plugin-arch').val(),
                detections:          {},
                attacks:             [],
                cpu_base:            $('#wpdss-cpu-base').val(),
                cpu_load:            $('#wpdss-cpu-load').val(),
                ram_base:            $('#wpdss-ram-base').val(),
                ram_load:            $('#wpdss-ram-load').val()
            };

            // Збираємо детекції з чекбоксів
            $('.wpdss-vuln-checkbox').each(function () {
                var v_code   = $(this).data('vuln');
                var detected = $(this).prop('checked') ? 1 : 0;
                data.detections[v_code] = detected;
            });

            // Атаки
            $('.wpdss-attack-row').each(function () {
                data.attacks.push({
                    type:     $(this).data('type'),
                    result:   $(this).find('select.wpdss-attack-result').val(),
                    evidence: $(this).find('input.wpdss-attack-evidence').val()
                });
            });

            $('.wpdss-wizard-save').prop('disabled', true).text('Збереження...');

            $.post(wpdssData.ajax_url, data, function (resp) {
                if (resp.success) {
                    alert('Тест збережено! ID плагіну: ' + resp.data.plugin_id);
                    location.reload();
                } else {
                    alert('Помилка: ' + (resp.data || 'unknown'));
                    $('.wpdss-wizard-save').prop('disabled', false).text('Зберегти результати');
                }
            });
        }
    };

    /* ==========================================================================
       DSS Recommendations — слайдери та оновлення
       ========================================================================== */

    var WPDSSRecommendations = {
        init: function () {
            var self = this;

            $('.wpdss-slider').on('input', function () {
                var $slider = $(this);
                var value = $slider.val();
                $slider.closest('.wpdss-slider-group').find('.wpdss-slider-value').text(value + '%');
                self.recalculate();
            });

            // Початковий розрахунок
            setTimeout(function () { self.recalculate(); }, 100);
        },

        recalculate: function () {
            var weights = {
                recall:  parseFloat($('#wpdss-w-recall').val())  / 100,
                block:   parseFloat($('#wpdss-w-block').val())   / 100,
                perf:    parseFloat($('#wpdss-w-perf').val())    / 100,
                offline: parseFloat($('#wpdss-w-offline').val()) / 100
            };

            // Якщо доступні дані плагінів через JS
            if (typeof window.wpdssPlugins !== 'undefined') {
                var ranked = WPDSSEngine.rankPlugins(window.wpdssPlugins, weights);
                this.renderRanking(ranked);
            } else {
                // AJAX до сервера
                $.post(wpdssData.ajax_url, {
                    action: 'wpdss_rank',
                    nonce: wpdssData.nonce,
                    w_recall:  weights.recall,
                    w_block:   weights.block,
                    w_perf:    weights.perf,
                    w_offline: weights.offline
                }, function (resp) {
                    if (resp.success) {
                        WPDSSRecommendations.renderRanking(resp.data);
                    }
                });
            }
        },

        renderRanking: function (ranked) {
            var html = '';
            ranked.forEach(function (p) {
                var rankClass = p.rank <= 3 ? ('rank-' + p.rank) : '';
                html += '<div class="wpdss-ranking-card ' + rankClass + '">';
                html +=   '<div class="wpdss-rank-number">' + p.rank + '</div>';
                html +=   '<div class="wpdss-rank-info">';
                html +=     '<h3>' + p.code + ' — ' + p.name + ' ' + (p.version || '') + '</h3>';
                html +=     '<div class="wpdss-rank-meta">';
                html +=       'Recall ' + p.recall + '% · Block ' + p.block_rate + '% · ';
                html +=       'Продукт. ' + p.perf_score + '% · ';
                html +=       (p.offline_capable ? '✓ Офлайн' : '✗ Потрібен інтернет');
                html +=     '</div>';
                html +=   '</div>';
                html +=   '<div class="wpdss-rank-score">';
                html +=     '<span class="label">DSS Score</span>';
                html +=     p.score;
                html +=   '</div>';
                html += '</div>';
            });

            $('#wpdss-ranking-results').html(html);
        }
    };

    /* ==========================================================================
       Ініціалізація після завантаження DOM
       ========================================================================== */

    $(function () {
        // Графіки на сторінці "Порівняння"
        // comparison.php передає дані через window.wpdssChartData
        if (typeof window.wpdssChartData !== 'undefined') {
            if (typeof Chart === 'undefined') {
                console.error('[WP Security DSS] Chart.js не завантажено. Перевірте мережу або наявність assets/js/chart.umd.min.js');
                $('.wpdss-card canvas').each(function () {
                    $(this).replaceWith(
                        '<div class="wpdss-notice wpdss-notice-warning">' +
                        '<strong>Chart.js не завантажено.</strong> ' +
                        'Можливі причини: блокування мережі (CDN недоступний), Ad-blocker, або відсутність файлу <code>assets/js/chart.umd.min.js</code>. ' +
                        'Дані доступні у таблиці нижче.' +
                        '</div>'
                    );
                });
                return;
            }

            var d = window.wpdssChartData;

            // ---- Графік 1: Recall vs Block Rate (Bar) ----
            var canvas1 = document.getElementById('chartRecallBlock');
            if (canvas1) {
                new Chart(canvas1, {
                    type: 'bar',
                    data: {
                        labels: d.labels,
                        datasets: [
                            {
                                label: 'Recall (%)',
                                data: d.recalls,
                                backgroundColor: '#2271b1',
                                borderRadius: 4
                            },
                            {
                                label: 'Block Rate (%)',
                                data: d.blocks,
                                backgroundColor: '#46b450',
                                borderRadius: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                ticks: { callback: function (v) { return v + '%'; } }
                            }
                        },
                        plugins: {
                            legend: { position: 'top' },
                            title: {
                                display: true,
                                text: 'Виявлення вразливостей vs Блокування атак'
                            }
                        }
                    }
                });
            }

            // ---- Графік 2: Δ CPU + Δ RAM (Bar, double axis) ----
            var canvas2 = document.getElementById('chartPerformance');
            if (canvas2) {
                new Chart(canvas2, {
                    type: 'bar',
                    data: {
                        labels: d.labels,
                        datasets: [
                            {
                                label: 'Δ CPU (%)',
                                data: d.cpus,
                                backgroundColor: '#dc3232',
                                yAxisID: 'y1',
                                borderRadius: 4
                            },
                            {
                                label: 'Δ RAM (MB)',
                                data: d.rams,
                                backgroundColor: '#ffb900',
                                yAxisID: 'y2',
                                borderRadius: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y1: {
                                type: 'linear',
                                position: 'left',
                                beginAtZero: true,
                                title: { display: true, text: 'CPU (%)' }
                            },
                            y2: {
                                type: 'linear',
                                position: 'right',
                                beginAtZero: true,
                                grid: { drawOnChartArea: false },
                                title: { display: true, text: 'RAM (MB)' }
                            }
                        },
                        plugins: {
                            legend: { position: 'top' },
                            title: {
                                display: true,
                                text: 'Навантаження плагінів на сервер'
                            }
                        }
                    }
                });
            }

            // ---- Графік 3: Radar (Recall, Block, Performance, FP, Monitoring) ----
            var canvas3 = document.getElementById('chartRadar');
            if (canvas3) {
                var perfScore = d.cpus.map(function (cpu, i) {
                    // Чим менше Δ CPU + Δ RAM/10, тим вище perf_score (інверсія)
                    var penalty = (cpu || 0) + (d.rams[i] || 0) / 10;
                    var score = Math.max(0, 100 - penalty);
                    return Math.round(score);
                });

                // Інвертований FP Rate (чим менше тим краще -> 100-FP*10)
                var fpScore = (d.fp_rates || []).map(function (fp) {
                    return Math.max(0, 100 - (fp || 0) * 10);
                });

                var monitoring = d.monitoring || d.labels.map(function () { return 50; });

                var datasets = d.labels.map(function (name, i) {
                    var color = d.colors[i];
                    return {
                        label: name,
                        data: [
                            d.recalls[i],
                            d.blocks[i] || 0,
                            perfScore[i],
                            fpScore[i] || 80,
                            monitoring[i] || 50
                        ],
                        borderColor: color,
                        backgroundColor: color + '22',
                        pointBackgroundColor: color,
                        borderWidth: 2,
                        pointRadius: 3
                    };
                });

                new Chart(canvas3, {
                    type: 'radar',
                    data: {
                        labels: ['Recall', 'Block Rate', 'Продуктивність', 'Точність (низький FP)', 'Моніторинг'],
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            r: {
                                min: 0,
                                max: 100,
                                ticks: { stepSize: 25 }
                            }
                        },
                        plugins: {
                            legend: { position: 'right', labels: { boxWidth: 12, font: { size: 10 } } },
                            title: {
                                display: true,
                                text: 'Інтегральне порівняння 11 плагінів безпеки за 5 критеріями'
                            }
                        }
                    }
                });
            }
        }

        // Кругові індикатори (анімація заповнення)
        $('.wpdss-circle-progress').each(function () {
            var $svg = $(this);
            var pct = parseFloat($svg.data('value')) || 0;
            var $circle = $svg.find('.wpdss-circle-fg');
            var r = parseFloat($circle.attr('r'));
            var circumference = 2 * Math.PI * r;
            $circle.attr('stroke-dasharray', circumference);
            $circle.attr('stroke-dashoffset', circumference);
            setTimeout(function () {
                $circle.attr('stroke-dashoffset', circumference * (1 - pct / 100));
            }, 200);
        });

        // Майстер
        if ($('.wpdss-wizard-content').length) {
            WPDSSWizard.init();
        }

        // DSS Рекомендації
        if ($('.wpdss-sliders-panel').length) {
            WPDSSRecommendations.init();
        }
    });

    // Експорт для зовнішнього використання
    window.WPDSS = {
        Utils: WPDSSUtils,
        Engine: WPDSSEngine,
        Charts: WPDSSCharts,
        Wizard: WPDSSWizard,
        Recommendations: WPDSSRecommendations
    };

})(jQuery);
