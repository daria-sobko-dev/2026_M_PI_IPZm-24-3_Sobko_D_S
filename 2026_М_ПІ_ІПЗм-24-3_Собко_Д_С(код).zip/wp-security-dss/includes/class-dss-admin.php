<?php
/**
 * Адмін-інтерфейс плагіну
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPDSS_Admin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_ajax_wpdss_rank', array( $this, 'ajax_rank' ) );
        add_action( 'wp_ajax_wpdss_save_test', array( $this, 'ajax_save_test' ) );
    }

    /**
     * Реєстрація меню в адмінці
     */
    public function register_menu() {
        // Головне меню
        add_menu_page(
            __( 'Security DSS', 'wp-security-dss' ),
            __( 'Security DSS', 'wp-security-dss' ),
            'manage_options',
            'wpdss-dashboard',
            array( $this, 'render_dashboard' ),
            'dashicons-shield-alt',
            65
        );

        // Підменю
        add_submenu_page( 'wpdss-dashboard', __( 'Dashboard', 'wp-security-dss' ),       __( 'Dashboard', 'wp-security-dss' ),       'manage_options', 'wpdss-dashboard',   array( $this, 'render_dashboard' ) );
        add_submenu_page( 'wpdss-dashboard', __( 'Порівняння', 'wp-security-dss' ),     __( 'Порівняння', 'wp-security-dss' ),     'manage_options', 'wpdss-comparison',  array( $this, 'render_comparison' ) );
        add_submenu_page( 'wpdss-dashboard', __( 'DSS Рекомендації', 'wp-security-dss' ), __( 'DSS Рекомендації', 'wp-security-dss' ), 'manage_options', 'wpdss-recommendations', array( $this, 'render_recommendations' ) );
        add_submenu_page( 'wpdss-dashboard', __( 'Майстер тестування', 'wp-security-dss' ), __( 'Майстер тестування', 'wp-security-dss' ), 'manage_options', 'wpdss-wizard', array( $this, 'render_wizard' ) );
        add_submenu_page( 'wpdss-dashboard', __( 'База результатів', 'wp-security-dss' ), __( 'База результатів', 'wp-security-dss' ), 'manage_options', 'wpdss-database', array( $this, 'render_database' ) );
        add_submenu_page( 'wpdss-dashboard', __( 'Налаштування', 'wp-security-dss' ),    __( 'Налаштування', 'wp-security-dss' ),    'manage_options', 'wpdss-settings',  array( $this, 'render_settings' ) );
    }

    /**
     * Підключаємо CSS і JS тільки на сторінках нашого плагіну
     */
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'wpdss' ) === false ) return;

        wp_enqueue_style(
            'wpdss-admin',
            WPDSS_PLUGIN_URL . 'assets/css/admin-style.css',
            array(),
            WPDSS_VERSION
        );

        // Chart.js — спершу локально, у разі помилки JS-код сам підвантажить з CDN
        $chartjs_local = WPDSS_PLUGIN_DIR . 'assets/js/chart.umd.min.js';
        if ( file_exists( $chartjs_local ) ) {
            wp_enqueue_script(
                'chartjs',
                WPDSS_PLUGIN_URL . 'assets/js/chart.umd.min.js',
                array(),
                '4.4.0',
                true
            );
        } else {
            // Fallback на CDN
            wp_enqueue_script(
                'chartjs',
                'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
                array(),
                '4.4.0',
                true
            );
        }

        wp_enqueue_script(
            'wpdss-admin',
            WPDSS_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery', 'chartjs' ),
            WPDSS_VERSION,
            true
        );

        wp_localize_script( 'wpdss-admin', 'wpdssData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpdss_ajax' ),
        ) );
    }

    /**
     * Рендер сторінок
     */
    public function render_dashboard()       { include WPDSS_PLUGIN_DIR . 'admin/views/dashboard.php'; }
    public function render_comparison()      { include WPDSS_PLUGIN_DIR . 'admin/views/comparison.php'; }
    public function render_recommendations() { include WPDSS_PLUGIN_DIR . 'admin/views/dss-recommendations.php'; }
    public function render_wizard()          { include WPDSS_PLUGIN_DIR . 'admin/views/test-wizard.php'; }
    public function render_database()        { include WPDSS_PLUGIN_DIR . 'admin/views/results-database.php'; }
    public function render_settings()        { include WPDSS_PLUGIN_DIR . 'admin/views/settings.php'; }

    /**
     * AJAX: розрахувати рейтинг за вагами
     */
    public function ajax_rank() {
        check_ajax_referer( 'wpdss_ajax', 'nonce' );

        $weights = array(
            'recall'  => floatval( $_POST['w_recall']  ?? 0.25 ),
            'block'   => floatval( $_POST['w_block']   ?? 0.25 ),
            'perf'    => floatval( $_POST['w_perf']    ?? 0.25 ),
            'offline' => floatval( $_POST['w_offline'] ?? 0.25 ),
        );

        $ranked = WPDSS_Recommendation::rank_plugins( $weights );
        wp_send_json_success( $ranked );
    }

    /**
     * AJAX: зберегти результати тесту з майстра
     */
    public function ajax_save_test() {
        check_ajax_referer( 'wpdss_ajax', 'nonce' );

        global $wpdb;
        $db = new WPDSS_Database();
        $prefix = $db->get_prefix();

        $plugin_code = sanitize_text_field( $_POST['plugin_code'] ?? '' );
        if ( empty( $plugin_code ) ) {
            wp_send_json_error( 'Missing plugin code' );
        }

        // Якщо плагіну ще немає — створюємо
        $plugin = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$prefix}plugins WHERE code = %s", $plugin_code ) );
        if ( ! $plugin ) {
            $wpdb->insert( $prefix . 'plugins', array(
                'code'         => $plugin_code,
                'name'         => sanitize_text_field( $_POST['plugin_name'] ?? '' ),
                'version'      => sanitize_text_field( $_POST['plugin_version'] ?? '' ),
                'architecture' => sanitize_text_field( $_POST['plugin_architecture'] ?? 'Unknown' ),
                'color'        => '#0073aa',
            ) );
            $plugin_id = $wpdb->insert_id;
        } else {
            $plugin_id = $plugin->id;
            // Видаляємо старі результати
            $wpdb->delete( $prefix . 'scan_results', array( 'plugin_id' => $plugin_id ) );
            $wpdb->delete( $prefix . 'attack_results', array( 'plugin_id' => $plugin_id ) );
            $wpdb->delete( $prefix . 'performance', array( 'plugin_id' => $plugin_id ) );
        }

        // Зберігаємо результати пасивного сканування
        $detections = $_POST['detections'] ?? array();
        foreach ( $detections as $v_code => $detected ) {
            $v_code = sanitize_text_field( $v_code );
            $vuln = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$prefix}vulnerabilities WHERE code = %s", $v_code ) );
            if ( $vuln ) {
                $wpdb->insert( $prefix . 'scan_results', array(
                    'plugin_id'        => $plugin_id,
                    'vulnerability_id' => $vuln->id,
                    'detected'         => intval( $detected ),
                ) );
            }
        }

        // Зберігаємо атаки
        $attacks = $_POST['attacks'] ?? array();
        foreach ( $attacks as $i => $attack ) {
            $wpdb->insert( $prefix . 'attack_results', array(
                'plugin_id'     => $plugin_id,
                'attack_number' => intval( $i ) + 1,
                'attack_type'   => sanitize_text_field( $attack['type'] ?? '' ),
                'result'        => sanitize_text_field( $attack['result'] ?? 'Pass' ),
                'evidence'      => sanitize_text_field( $attack['evidence'] ?? '' ),
            ) );
        }

        // Продуктивність
        $wpdb->insert( $prefix . 'performance', array(
            'plugin_id'    => $plugin_id,
            'cpu_base'     => floatval( $_POST['cpu_base'] ?? 5 ),
            'cpu_load'     => floatval( $_POST['cpu_load'] ?? 10 ),
            'ram_base_mb'  => intval( $_POST['ram_base'] ?? 40 ),
            'ram_load_mb'  => intval( $_POST['ram_load'] ?? 100 ),
        ) );

        wp_send_json_success( array( 'plugin_id' => $plugin_id ) );
    }
}
