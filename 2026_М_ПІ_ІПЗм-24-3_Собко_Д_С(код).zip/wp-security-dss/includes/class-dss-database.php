<?php
/**
 * Клас для роботи з базою даних плагіну
 * WP Security DSS v2.0 — фінальна версія з 51 уразливим плагіном та 11 плагінами безпеки
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPDSS_Database {

    private $prefix;

    public function __construct() {
        global $wpdb;
        $this->prefix = $wpdb->prefix . 'wpdss_';
    }

    public function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();

        $table_plugins = $this->prefix . 'plugins';
        $sql1 = "CREATE TABLE $table_plugins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(10) NOT NULL,
            name VARCHAR(255) NOT NULL,
            version VARCHAR(50),
            type VARCHAR(20) DEFAULT 'Free',
            architecture VARCHAR(100),
            wp_slug VARCHAR(255),
            color VARCHAR(7) DEFAULT '#0073aa',
            installs VARCHAR(50),
            is_active TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY code (code)
        ) $charset_collate;";

        $table_vulnerabilities = $this->prefix . 'vulnerabilities';
        $sql2 = "CREATE TABLE $table_vulnerabilities (
            id INT AUTO_INCREMENT PRIMARY KEY,
            num INT NOT NULL,
            name VARCHAR(255) NOT NULL,
            version VARCHAR(50),
            cve VARCHAR(50),
            attack_class VARCHAR(50),
            cvss DECIMAL(3,1),
            is_ecommerce TINYINT(1) DEFAULT 0,
            wp_slug VARCHAR(255),
            UNIQUE KEY num (num)
        ) $charset_collate;";

        $table_scan_results = $this->prefix . 'scan_results';
        $sql3 = "CREATE TABLE $table_scan_results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            plugin_id INT NOT NULL,
            detected_xss INT DEFAULT 0,
            detected_sqli INT DEFAULT 0,
            detected_rce INT DEFAULT 0,
            detected_csrf INT DEFAULT 0,
            detected_auth INT DEFAULT 0,
            detected_file INT DEFAULT 0,
            detected_other INT DEFAULT 0,
            detected_total INT DEFAULT 0,
            recall_percent DECIMAL(5,2),
            fp_count INT DEFAULT 0,
            fp_rate DECIMAL(5,2),
            scan_time_minutes DECIMAL(6,2),
            monitoring_percent INT,
            tested_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        $table_attack_results = $this->prefix . 'attack_results';
        $sql4 = "CREATE TABLE $table_attack_results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            plugin_id INT NOT NULL,
            brute_force VARCHAR(50),
            sqli_waf VARCHAR(20),
            xss_waf VARCHAR(20),
            csrf_protect VARCHAR(20),
            eicar_detect VARCHAR(20),
            total_score VARCHAR(10),
            tested_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        $table_performance = $this->prefix . 'performance';
        $sql5 = "CREATE TABLE $table_performance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            plugin_id INT NOT NULL,
            response_time_sec DECIMAL(5,2),
            cpu_overhead DECIMAL(5,2),
            ram_overhead INT,
            tested_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        dbDelta( $sql1 );
        dbDelta( $sql2 );
        dbDelta( $sql3 );
        dbDelta( $sql4 );
        dbDelta( $sql5 );
    }

    public function seed_initial_data() {
        global $wpdb;

        // ============================================================
        // 1. 11 ЗАХИСНИХ ПЛАГІНІВ
        // ============================================================
        $plugins = array(
            array( 'code' => 'A1',  'name' => 'Wordfence Security',         'version' => '8.2.1',  'architecture' => 'Локальна CVE-база + WAF',          'wp_slug' => 'wordfence/wordfence.php',                       'color' => '#00709e', 'installs' => '3,000,000+' ),
            array( 'code' => 'A2',  'name' => 'Sucuri Security',            'version' => '2.7.2',  'architecture' => 'Local + Cloud SiteCheck',          'wp_slug' => 'sucuri-scanner/sucuri.php',                     'color' => '#d63638', 'installs' => '700,000+' ),
            array( 'code' => 'A3',  'name' => 'Solid Security (iThemes)',   'version' => '10.0.1', 'architecture' => 'Cloud Patchstack API',             'wp_slug' => 'better-wp-security/better-wp-security.php',     'color' => '#2563eb', 'installs' => '1,000,000+' ),
            array( 'code' => 'A4',  'name' => 'WP Cerber Security',         'version' => '9.7.3',  'architecture' => 'Local Integrity + Traffic Insp.',  'wp_slug' => 'wp-cerber/wp-cerber.php',                       'color' => '#7c3aed', 'installs' => '200,000+' ),
            array( 'code' => 'A5',  'name' => 'MalCare Security',           'version' => '6.44',   'architecture' => 'Cloud AWS Scanner',                'wp_slug' => 'malcare-security/malcare.php',                  'color' => '#f97316', 'installs' => '100,000+' ),
            array( 'code' => 'A6',  'name' => 'SecuPress',                  'version' => '2.6.1',  'architecture' => 'Локальна + Cloud',                 'wp_slug' => 'secupress/secupress.php',                       'color' => '#10b981', 'installs' => '30,000+' ),
            array( 'code' => 'A7',  'name' => 'Security Ninja',             'version' => '5.283',  'architecture' => 'Local scan engine',                'wp_slug' => 'security-ninja/security-ninja.php',             'color' => '#ec4899', 'installs' => '10,000+' ),
            array( 'code' => 'A8',  'name' => 'BulletProof Security',       'version' => '7.2',    'architecture' => 'File signature analysis',          'wp_slug' => 'bulletproof-security/bulletproof-security.php', 'color' => '#84cc16', 'installs' => '60,000+' ),
            array( 'code' => 'A9',  'name' => 'All-In-One Security (AIOS)', 'version' => '5.4.7',  'architecture' => 'Local rules + Firewall',           'wp_slug' => 'all-in-one-wp-security-and-firewall/wp-security.php', 'color' => '#06b6d4', 'installs' => '900,000+' ),
            array( 'code' => 'A10', 'name' => 'Titan Anti-spam & Security', 'version' => '7.5.2',  'architecture' => 'Anti-spam + File scan',            'wp_slug' => 'anti-spam/anti-spam.php',                       'color' => '#f59e0b', 'installs' => '100,000+' ),
            array( 'code' => 'A11', 'name' => 'NinjaFirewall (WP Edition)', 'version' => '4.8.5',  'architecture' => 'Standalone PHP-level WAF',         'wp_slug' => 'ninjafirewall/ninjafirewall.php',               'color' => '#8b5cf6', 'installs' => '50,000+' ),
        );

        $table = $this->prefix . 'plugins';
        foreach ( $plugins as $p ) {
            $wpdb->replace( $table, $p );
        }

        // ============================================================
        // 2. 51 УРАЗЛИВИЙ ПЛАГІН
        // ============================================================
        $vulnerabilities = array(
            array(  1, 'GutenKit Blocks',                  '2.1.0',    'CVE-2024-9234',  'RCE',           9.8, 0, 'gutenkit-blocks-addon' ),
            array(  2, 'Give - Donation Plugin',           '3.16.0',   'CVE-2024-8353',  'RCE',           9.8, 1, 'give' ),
            array(  3, 'WP Super Cache',                   '1.7.0',    'CVE-2021-24209', 'RCE',           9.8, 0, 'wp-super-cache' ),
            array(  4, 'WP-Advanced-Search',               '3.3.3',    'CVE-2020-9381',  'SQLi',          8.1, 0, 'wp-advanced-search' ),
            array(  5, 'Redux Framework',                  '4.4.17',   'CVE-2024-6828',  'XSS',           6.1, 0, 'redux-framework' ),
            array(  6, 'Contact Form 7',                   '5.3.1',    'CVE-2021-24145', 'XSS',           6.5, 0, 'contact-form-7' ),
            // Note: WP-Optimize має slug "wp-optimize" але в адмінці називається "WP-Optimize - Clean, Compress, Cache"
            array(  7, 'Mailchimp for WooCommerce',        '2.6.0',    'CVE-2023-4762',  'Auth Bypass',   9.8, 1, 'mailchimp-for-woocommerce' ),
            array(  8, 'Yoast SEO',                        '15.1',     'CVE-2021-25032', 'XSS',           6.1, 0, 'wordpress-seo' ),
            array(  9, 'WPForms Lite',                     '1.6.7',    'CVE-2022-3150',  'CSRF',          4.3, 0, 'wpforms-lite' ),
            array( 10, 'All in One SEO',                   '4.1.6',    'CVE-2021-25036', 'SQLi/XSS',      9.9, 0, 'all-in-one-seo-pack' ),
            array( 11, 'WooCommerce PayPal Payments',      '1.9.0',    'CVE-2022-25027', 'Auth Bypass',   9.8, 1, 'woocommerce-paypal-payments' ),
            array( 12, 'Two Factor',                       '0.7.0',    'CVE-2022-2820',  'Auth Bypass',   9.8, 0, 'two-factor' ),
            array( 13, 'Duplicator',                       '1.3.26',   'CVE-2020-11738', 'File Download', 7.5, 0, 'duplicator' ),
            array( 14, 'Better Search Replace',            '1.4.0',    'CVE-2023-6933',  'Privilege Esc.',9.1, 0, 'better-search-replace' ),
            array( 15, 'Social Warfare',                   '3.5.2',    'CVE-2019-9978',  'RCE',           9.8, 0, 'social-warfare' ),
            array( 16, 'Auto Affiliate Links',             '6.4.3',    'CVE-2024-34386', 'SQLi',          8.8, 1, 'auto-affiliate-links' ),
            array( 17, 'WooCommerce Stripe Gateway',       '6.0.0',    'CVE-2022-25149', 'File Upload',   9.8, 1, 'woocommerce-gateway-stripe' ),
            array( 18, 'MailPoet',                         '3.84.0',   'CVE-2022-1936',  'SQLi',          9.8, 1, 'mailpoet' ),
            array( 19, 'Sassy Social Share',               '3.3.58',   'CVE-2024-1989',  'XSS',           6.1, 1, 'sassy-social-share' ),
            array( 20, 'LiteSpeed Cache',                  '5.6',      'CVE-2023-40000', 'XSS',           8.3, 1, 'litespeed-cache' ),
            array( 21, 'WP Statistics',                    '14.4',     'CVE-2024-2194',  'XSS',           6.4, 0, 'wp-statistics' ),
            array( 22, 'Search & Replace',                 '3.2.1',    'CVE-2023-3007',  'SQLi',          7.2, 0, 'search-and-replace' ),
            array( 23, 'Popup Maker',                      '1.19.0',   'CVE-2024-7054',  'XSS',           6.4, 0, 'popup-maker' ),
            array( 24, 'Responsive Lightbox & Gallery',    '2.4.7',    'CVE-2024-43924', 'BAC',           5.4, 0, 'responsive-lightbox' ),
            array( 25, 'Akismet Anti-spam',                '5.7',      'CVE-2015-9357',  'XSS',           6.1, 0, 'akismet' ),
            array( 26, 'Advanced Custom Fields',           '6.8.1',    'CVE-2022-1592',  'XSS',           6.1, 0, 'advanced-custom-fields' ),
            array( 27, 'Antispam Bee',                     '2.11.11',  'CVE-2021-24295', 'XSS',           6.1, 0, 'antispam-bee' ),
            array( 28, 'aThemes Blocks',                   '1.1.4',    'CVE-2023-2001',  'XSS',           6.4, 0, 'athemes-blocks' ),
            array( 29, 'aThemes Starter Sites',            '1.1.9',    'CVE-2023-2002',  'CSRF',          5.4, 0, 'athemes-starter-sites' ),
            array( 30, 'Beaver Builder Lite',              '2.10.1.5', 'CVE-2021-24946', 'XSS',           6.1, 0, 'beaver-builder-lite-version' ),
            array( 31, 'Classic Editor',                   '1.6.7',    'CVE-2019-17671', 'Info Disclosure',5.3,0, 'classic-editor' ),
            array( 32, 'Classic Widgets',                  '0.3',      'CVE-2022-2055',  'XSS',           5.4, 0, 'classic-widgets' ),
            array( 33, 'Custom Post Type UI',              '1.19.2',   'CVE-2022-3457',  'CSRF',          4.3, 0, 'custom-post-type-ui' ),
            array( 34, 'Forminator',                       '1.53.2',   'CVE-2023-35069', 'XSS',           6.4, 0, 'forminator' ),
            array( 35, 'MonsterInsights',                  '10.2.0',   'CVE-2022-3576',  'CSRF',          5.4, 0, 'google-analytics-for-wordpress' ),
            array( 36, 'Health Check & Troubleshooting',   '1.7.1',    'CVE-2021-24364', 'Info Disclosure',5.3,0, 'health-check' ),
            array( 37, 'Loco Translate',                   '2.8.4',    'CVE-2022-1442',  'XSS',           6.4, 0, 'loco-translate' ),
            array( 38, 'MC4WP: Mailchimp',                 '4.12.5',   'CVE-2022-3699',  'XSS',           6.1, 0, 'mailchimp-for-wp' ),
            array( 39, 'Ninja Forms',                      '3.14.4',   'CVE-2023-37979', 'XSS',           6.1, 0, 'ninja-forms' ),
            array( 40, 'Page Builder by SiteOrigin',       '2.34.1',   'CVE-2022-1622',  'XSS',           6.1, 0, 'siteorigin-panels' ),
            array( 41, 'Polylang',                         '3.8.4',    'CVE-2022-23854', 'XSS',           6.4, 0, 'polylang' ),
            array( 42, 'Query Monitor',                    '4.0.6',    'CVE-2022-4144',  'Info Disclosure',5.3,0, 'query-monitor' ),
            array( 43, 'SEOPress',                         '9.8.5',    'CVE-2022-0922',  'XSS',           6.1, 0, 'wp-seopress' ),
            array( 44, 'Site Kit by Google',               '1.179.0',  'CVE-2023-28115', 'Auth Bypass',   7.5, 0, 'google-site-kit' ),
            array( 45, 'Smush',                            '4.0.3',    'CVE-2022-0951',  'XSS',           6.4, 0, 'wp-smushit' ),
            array( 46, 'Spectra',                          '2.19.27',  'CVE-2023-3712',  'XSS',           6.1, 0, 'ultimate-addons-for-gutenberg' ),
            array( 47, 'Stackable - Gutenberg Blocks',     '3.19.8',   'CVE-2023-39998', 'XSS',           6.1, 0, 'stackable-ultimate-gutenberg-blocks' ),
            array( 48, 'TablePress',                       '3.3.1',    'CVE-2021-24809', 'XSS',           6.1, 0, 'tablepress' ),
            array( 49, 'The Events Calendar',              '6.16.2',   'CVE-2023-28109', 'XSS',           6.4, 0, 'the-events-calendar' ),
            array( 50, 'UpdraftPlus - Backup/Restore',     '1.26.4',   'CVE-2022-0633',  'Info Disclosure',7.5,0, 'updraftplus' ),
            array( 51, 'WooCommerce Tax',                  '3.6.3',    'CVE-2023-37999', 'CSRF',          4.3, 1, 'woocommerce-services' ),
        );

        $table = $this->prefix . 'vulnerabilities';
        foreach ( $vulnerabilities as $v ) {
            $wpdb->replace( $table, array(
                'num'           => $v[0],
                'name'          => $v[1],
                'version'       => $v[2],
                'cve'           => $v[3],
                'attack_class'  => $v[4],
                'cvss'          => $v[5],
                'is_ecommerce'  => $v[6],
                'wp_slug'       => $v[7],
            ) );
        }

        // ============================================================
        // 3. РЕЗУЛЬТАТИ СКАНУВАННЯ (Таблиці Д.2 + Д.3)
        // ============================================================
        $scan_data = array(
            'A1'  => array( 14, 6, 5, 3, 4, 4, 2, 38, 82.4, 3, 7.2, 14.3, 80 ),
            'A2'  => array( 17, 7, 5, 4, 4, 4, 2, 43, 84.3, 1, 1.1, 12.1, 80 ),
            'A3'  => array( 12, 5, 4, 3, 3, 3, 2, 32, 62.7, 2, 3.4,  8.5, 95 ),
            'A4'  => array( 13, 6, 4, 3, 3, 3, 2, 34, 66.7, 3, 6.8,  9.7, 80 ),
            'A5'  => array( 18, 8, 6, 5, 5, 4, 3, 49, 96.1, 1, 0.8, 11.4, 60 ),
            'A6'  => array( 16, 7, 6, 4, 4, 3, 3, 43, 84.3, 1, 2.3, 10.2, 75 ),
            'A7'  => array( 10, 4, 3, 2, 3, 2, 1, 25, 49.0, 2, 4.5,  7.8, 70 ),
            'A8'  => array(  8, 3, 2, 1, 2, 2, 1, 19, 37.3, 4, 8.1,  6.3, 50 ),
            'A9'  => array( 11, 5, 3, 2, 3, 2, 1, 27, 52.9, 1, 2.1,  7.2, 65 ),
            'A10' => array(  5, 2, 1, 1, 1, 1, 0, 11, 21.6, 3, 5.7,  5.1, 40 ),
            'A11' => array( 15, 7, 5, 4, 4, 3, 2, 40, 78.4, 1, 1.5,  9.8, 85 ),
        );

        $table = $this->prefix . 'scan_results';
        foreach ( $scan_data as $code => $d ) {
            $plugin = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$this->prefix}plugins WHERE code = %s", $code ) );
            if ( ! $plugin ) continue;

            $wpdb->insert( $table, array(
                'plugin_id'          => $plugin->id,
                'detected_xss'       => $d[0],
                'detected_sqli'      => $d[1],
                'detected_rce'       => $d[2],
                'detected_csrf'      => $d[3],
                'detected_auth'      => $d[4],
                'detected_file'      => $d[5],
                'detected_other'     => $d[6],
                'detected_total'     => $d[7],
                'recall_percent'     => $d[8],
                'fp_count'           => $d[9],
                'fp_rate'            => $d[10],
                'scan_time_minutes'  => $d[11],
                'monitoring_percent' => $d[12],
            ) );
        }

        // ============================================================
        // 4. РЕЗУЛЬТАТИ АКТИВНИХ АТАК (Таблиця Д.4)
        // ============================================================
        $attack_data = array(
            'A1'  => array( 'Так (5 спроб)',  'Так',       'Так',       'Ні',       'Так', '4/5' ),
            'A2'  => array( 'Так (3 спроби)', 'Так',       'Так',       'Так',      'Так', '5/5' ),
            'A3'  => array( 'Так (5 спроб)',  'Частково',  'Ні',        'Ні',       'Так', '2.5/5' ),
            'A4'  => array( 'Так (3 спроби)', 'Так',       'Так',       'Ні',       'Так', '4/5' ),
            'A5'  => array( 'Так (10 спроб)', 'Так',       'Так',       'Так',      'Так', '5/5' ),
            'A6'  => array( 'Так (5 спроб)',  'Так',       'Частково',  'Ні',       'Так', '3.5/5' ),
            'A7'  => array( 'Ні',             'Ні',        'Ні',        'Ні',       'Так', '1/5' ),
            'A8'  => array( 'Так (10 спроб)', 'Частково',  'Ні',        'Ні',       'Ні',  '1.5/5' ),
            'A9'  => array( 'Так (3 спроби)', 'Частково',  'Ні',        'Ні',       'Так', '2.5/5' ),
            'A10' => array( 'Ні',             'Ні',        'Ні',        'Ні',       'Ні',  '0/5' ),
            'A11' => array( 'Так (3 спроби)', 'Так',       'Так',       'Частково', 'Так', '4.5/5' ),
        );

        $table = $this->prefix . 'attack_results';
        foreach ( $attack_data as $code => $d ) {
            $plugin = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$this->prefix}plugins WHERE code = %s", $code ) );
            if ( ! $plugin ) continue;

            $wpdb->insert( $table, array(
                'plugin_id'    => $plugin->id,
                'brute_force'  => $d[0],
                'sqli_waf'     => $d[1],
                'xss_waf'      => $d[2],
                'csrf_protect' => $d[3],
                'eicar_detect' => $d[4],
                'total_score'  => $d[5],
            ) );
        }

        // ============================================================
        // 5. ПРОДУКТИВНІСТЬ (Таблиця Д.3)
        // ============================================================
        $performance = array(
            'A1'  => array( 5.2, 18, 78 ),
            'A2'  => array( 4.8,  6, 22 ),
            'A3'  => array( 1.2,  4, 18 ),
            'A4'  => array( 1.4, 16, 75 ),
            'A5'  => array( 1.1, 19, 82 ),
            'A6'  => array( 2.1,  8, 35 ),
            'A7'  => array( 3.5, 10, 42 ),
            'A8'  => array( 2.8, 12, 55 ),
            'A9'  => array( 1.8,  3, 15 ),
            'A10' => array( 4.2,  8, 38 ),
            'A11' => array( 0.8,  2, 12 ),
        );

        $table = $this->prefix . 'performance';
        foreach ( $performance as $code => $p ) {
            $plugin = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$this->prefix}plugins WHERE code = %s", $code ) );
            if ( ! $plugin ) continue;

            $wpdb->insert( $table, array(
                'plugin_id'         => $plugin->id,
                'response_time_sec' => $p[0],
                'cpu_overhead'      => $p[1],
                'ram_overhead'      => $p[2],
            ) );
        }
    }

    public function get_all_plugins_with_metrics() {
        global $wpdb;

        $plugins = $wpdb->get_results( "SELECT * FROM {$this->prefix}plugins ORDER BY id" );

        foreach ( $plugins as &$plugin ) {
            $scan = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$this->prefix}scan_results WHERE plugin_id = %d ORDER BY tested_at DESC LIMIT 1",
                $plugin->id
            ) );
            $plugin->recall = $scan ? (float) $scan->recall_percent : 0;
            $plugin->detected_count = $scan ? (int) $scan->detected_total : 0;
            $plugin->total_count = 51;
            $plugin->fp_rate = $scan ? (float) $scan->fp_rate : 0;
            $plugin->fp_count = $scan ? (int) $scan->fp_count : 0;
            $plugin->scan_time = $scan ? (float) $scan->scan_time_minutes : 0;
            $plugin->monitoring = $scan ? (int) $scan->monitoring_percent : 0;

            $attack = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$this->prefix}attack_results WHERE plugin_id = %d ORDER BY tested_at DESC LIMIT 1",
                $plugin->id
            ) );
            $plugin->brute_force = $attack ? $attack->brute_force : '—';
            $plugin->sqli_waf = $attack ? $attack->sqli_waf : '—';
            $plugin->xss_waf = $attack ? $attack->xss_waf : '—';
            $plugin->csrf_protect = $attack ? $attack->csrf_protect : '—';
            $plugin->eicar_detect = $attack ? $attack->eicar_detect : '—';
            $plugin->total_score = $attack ? $attack->total_score : '0/5';
            
            if ( $attack && $attack->total_score ) {
                $parts = explode( '/', $attack->total_score );
                if ( count( $parts ) === 2 && (float) $parts[1] > 0 ) {
                    $plugin->block_rate = round( ( (float) $parts[0] / (float) $parts[1] ) * 100, 1 );
                    $plugin->blocks_count = (float) $parts[0];
                } else {
                    $plugin->block_rate = 0;
                    $plugin->blocks_count = 0;
                }
            } else {
                $plugin->block_rate = 0;
                $plugin->blocks_count = 0;
            }
            $plugin->attacks_count = 5;

            $perf = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$this->prefix}performance WHERE plugin_id = %d ORDER BY tested_at DESC LIMIT 1",
                $plugin->id
            ) );
            $plugin->response_time = $perf ? (float) $perf->response_time_sec : 0;
            $plugin->cpu_delta = $perf ? (float) $perf->cpu_overhead : 0;
            $plugin->ram_delta = $perf ? (int) $perf->ram_overhead : 0;
        }

        return $plugins;
    }

    public function get_all_vulnerabilities() {
        global $wpdb;
        return $wpdb->get_results( "SELECT * FROM {$this->prefix}vulnerabilities ORDER BY num" );
    }

    public function get_detection_matrix() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT p.code, p.name, p.color,
                    s.detected_xss, s.detected_sqli, s.detected_rce,
                    s.detected_csrf, s.detected_auth, s.detected_file, s.detected_other, s.detected_total
             FROM {$this->prefix}plugins p
             LEFT JOIN {$this->prefix}scan_results s ON p.id = s.plugin_id
             ORDER BY p.id"
        );
    }

    public function get_prefix() {
        return $this->prefix;
    }
}
