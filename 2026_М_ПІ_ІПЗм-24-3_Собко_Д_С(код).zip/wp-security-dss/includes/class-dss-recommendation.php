<?php
/**
 * DSS-движок — багатокритеріальне ранжування плагінів
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPDSS_Recommendation {

    /**
     * Виконати ранжування за вагами користувача
     *
     * @param array $weights ['recall' => 0.30, 'block' => 0.30, 'perf' => 0.20, 'offline' => 0.20]
     * @return array Відсортований масив плагінів зі score і rank
     */
    public static function rank_plugins( $weights ) {
        $db = new WPDSS_Database();
        $plugins = $db->get_all_plugins_with_metrics();

        // Знаходимо межі продуктивності для нормалізації
        $cpu_values = array();
        $ram_values = array();
        foreach ( $plugins as $p ) {
            if ( $p->cpu_delta !== null ) $cpu_values[] = $p->cpu_delta;
            if ( $p->ram_delta !== null ) $ram_values[] = $p->ram_delta;
        }

        $cpu_worst = empty( $cpu_values ) ? 100 : max( $cpu_values );
        $cpu_best  = empty( $cpu_values ) ? 0   : min( $cpu_values );
        $ram_worst = empty( $ram_values ) ? 1000 : max( $ram_values );
        $ram_best  = empty( $ram_values ) ? 0    : min( $ram_values );

        // Рахуємо score для кожного плагіну
        $ranked = array();
        foreach ( $plugins as $p ) {
            // Якщо block_rate не виміряний (пасивно тільки) — 0
            $block_rate = $p->block_rate !== null ? $p->block_rate : 0;

            // Нормалізуємо продуктивність (менше = краще)
            $cpu_score = $p->cpu_delta !== null
                ? WPDSS_Calculator::normalize_performance( $p->cpu_delta, $cpu_worst, $cpu_best )
                : 50;
            $ram_score = $p->ram_delta !== null
                ? WPDSS_Calculator::normalize_performance( $p->ram_delta, $ram_worst, $ram_best )
                : 50;
            $perf_score = ( $cpu_score + $ram_score ) / 2;

            // Offline capability — 1 якщо архітектура локальна, 0 якщо облачна
            $offline = ( stripos( $p->architecture, 'Local' ) !== false ) ? 1 : 0;

            // Інтегральний score
            $score = WPDSS_Calculator::calculate_dss_score( array(
                'recall'     => $p->recall,
                'block_rate' => $block_rate,
                'perf_score' => $perf_score,
                'offline'    => $offline,
            ), $weights );

            $ranked[] = array(
                'code'          => $p->code,
                'name'          => $p->name,
                'version'       => $p->version,
                'architecture'  => $p->architecture,
                'color'         => $p->color,
                'recall'        => $p->recall,
                'block_rate'    => $block_rate,
                'cpu_delta'     => $p->cpu_delta,
                'ram_delta'     => $p->ram_delta,
                'perf_score'    => round( $perf_score, 1 ),
                'offline'       => $offline,
                'score'         => $score,
            );
        }

        // Сортуємо за score (більше = краще)
        usort( $ranked, function( $a, $b ) {
            return $b['score'] <=> $a['score'];
        } );

        // Розставляємо ранги
        foreach ( $ranked as $i => &$r ) {
            $r['rank'] = $i + 1;
            if ( $i == 0 ) $r['recommendation'] = 'recommended';
            elseif ( $i == 1 || $i == 2 ) $r['recommendation'] = 'good';
            else $r['recommendation'] = 'not_recommended';
        }

        return $ranked;
    }

    /**
     * Стандартні набори ваг для типових сценаріїв
     */
    public static function get_preset_scenarios() {
        return array(
            'balanced' => array(
                'label' => 'Збалансований підхід',
                'description' => 'Усі критерії однаково важливі',
                'weights' => array( 'recall' => 0.25, 'block' => 0.25, 'perf' => 0.25, 'offline' => 0.25 ),
            ),
            'maximum_security' => array(
                'label' => 'Максимальна безпека',
                'description' => 'Пріоритет — захист, продуктивність другорядна',
                'weights' => array( 'recall' => 0.40, 'block' => 0.40, 'perf' => 0.10, 'offline' => 0.10 ),
            ),
            'performance_first' => array(
                'label' => 'Пріоритет продуктивності',
                'description' => 'Мінімальне навантаження на сервер',
                'weights' => array( 'recall' => 0.20, 'block' => 0.20, 'perf' => 0.50, 'offline' => 0.10 ),
            ),
            'offline_critical' => array(
                'label' => 'Автономність критична',
                'description' => 'Сайт повинен бути захищений без хмарних сервісів',
                'weights' => array( 'recall' => 0.25, 'block' => 0.20, 'perf' => 0.15, 'offline' => 0.40 ),
            ),
            'ecommerce' => array(
                'label' => 'E-commerce сайт (WooCommerce)',
                'description' => 'Захист від атак + швидкість',
                'weights' => array( 'recall' => 0.30, 'block' => 0.35, 'perf' => 0.25, 'offline' => 0.10 ),
            ),
        );
    }
}
