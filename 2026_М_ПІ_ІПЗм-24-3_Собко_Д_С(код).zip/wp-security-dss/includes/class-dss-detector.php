<?php
/**
 * Детектор установлених плагінів
 * v2.0 — гнучкий пошук плагінів за множинними slug'ами
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPDSS_Detector {

    /**
     * Альтернативні slug'и для пошуку (для випадків коли реальний slug відрізняється від основного)
     */
    private static function get_security_slugs_map() {
        return array(
            'A1' => array( 'wordfence/wordfence.php' ),
            'A2' => array( 'sucuri-scanner/sucuri.php' ),
            'A3' => array( 'kadence-security/kadence-security.php', 'better-wp-security/better-wp-security.php' ),
            'A4' => array( 'wp-cerber/wp-cerber.php' ),
            'A5' => array( 'malcare-security/malcare.php' ),
            'A6' => array( 'secupress-free/secupress-free.php', 'secupress/secupress.php' ),
            'A7' => array( 'security-ninja/security-ninja.php' ),
            'A8' => array( 'bulletproof-security/bulletproof-security.php' ),
            'A9' => array( 'all-in-one-wp-security-and-firewall/wp-security.php' ),
            'A10' => array( 'anti-spam/anti-spam.php' ),
            'A11' => array( 'ninjafirewall/ninjafirewall.php' ),
        );
    }

    /**
     * Знайти всі захисні плагіни (A1-A11) встановлені на сайті
     * Шукає за wp_slug з БД та за альтернативними slug'ами,
     * також за частковим співпадінням імені.
     */
    public static function detect_security_plugins() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        global $wpdb;
        $db = new WPDSS_Database();
        $known = $wpdb->get_results( "SELECT * FROM " . $db->get_prefix() . "plugins ORDER BY id" );

        $all_plugins = get_plugins();
        $slugs_map = self::get_security_slugs_map();
        $detected = array();

        foreach ( $known as $plugin ) {
            $matched = null;

            // 1. Точний пошук по slug з БД
            if ( isset( $all_plugins[ $plugin->wp_slug ] ) ) {
                $matched = array( 'path' => $plugin->wp_slug, 'info' => $all_plugins[ $plugin->wp_slug ] );
            }

            // 2. Альтернативні slug'и
            if ( ! $matched && isset( $slugs_map[ $plugin->code ] ) ) {
                foreach ( $slugs_map[ $plugin->code ] as $alt_slug ) {
                    if ( isset( $all_plugins[ $alt_slug ] ) ) {
                        $matched = array( 'path' => $alt_slug, 'info' => $all_plugins[ $alt_slug ] );
                        break;
                    }
                }
            }

            // 3. Пошук за іменем (часткове співпадіння)
            if ( ! $matched ) {
                $clean_name = strtolower( preg_replace( '/[^a-z0-9]/i', '', $plugin->name ) );
                foreach ( $all_plugins as $path => $info ) {
                    $clean_info = strtolower( preg_replace( '/[^a-z0-9]/i', '', $info['Name'] ) );
                    if ( strpos( $clean_info, $clean_name ) !== false || strpos( $clean_name, $clean_info ) !== false ) {
                        // Перевіряємо що це дійсно security plugin а не випадкове співпадіння
                        if ( strlen( $clean_name ) > 5 && strlen( $clean_info ) > 5 ) {
                            $matched = array( 'path' => $path, 'info' => $info );
                            break;
                        }
                    }
                }
            }

            $detected[] = array(
                'code'              => $plugin->code,
                'name'              => $plugin->name,
                'expected_version'  => $plugin->version,
                'installed_version' => $matched ? $matched['info']['Version'] : null,
                'is_installed'      => $matched !== null,
                'is_active'         => $matched ? is_plugin_active( $matched['path'] ) : false,
                'wp_slug'           => $matched ? $matched['path'] : $plugin->wp_slug,
                'color'             => $plugin->color,
                'architecture'      => $plugin->architecture,
            );
        }

        return $detected;
    }

    /**
     * Знайти всі уразливі плагіни (51) встановлені на сайті
     */
    public static function detect_vulnerable_plugins() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        global $wpdb;
        $db = new WPDSS_Database();
        $known = $wpdb->get_results( "SELECT * FROM " . $db->get_prefix() . "vulnerabilities ORDER BY num" );

        $all_plugins = get_plugins();
        $detected = array();

        foreach ( $known as $vuln ) {
            $matched = null;

            // 1. Пошук по wp_slug як префіксу
            foreach ( $all_plugins as $path => $info ) {
                if ( strpos( $path, $vuln->wp_slug . '/' ) === 0 ) {
                    $matched = array( 'path' => $path, 'info' => $info );
                    break;
                }
            }

            // 2. Пошук за іменем (часткове співпадіння)
            if ( ! $matched ) {
                $clean_name = strtolower( preg_replace( '/[^a-z0-9]/i', '', $vuln->name ) );
                if ( strlen( $clean_name ) >= 5 ) {
                    foreach ( $all_plugins as $path => $info ) {
                        $clean_info = strtolower( preg_replace( '/[^a-z0-9]/i', '', $info['Name'] ) );
                        if ( strlen( $clean_info ) >= 5 && ( strpos( $clean_info, $clean_name ) === 0 || strpos( $clean_name, $clean_info ) === 0 ) ) {
                            $matched = array( 'path' => $path, 'info' => $info );
                            break;
                        }
                    }
                }
            }

            if ( $matched ) {
                $is_vulnerable_version = version_compare( $matched['info']['Version'], $vuln->version, '<=' );
                $detected[] = array(
                    'num'                => $vuln->num,
                    'name'               => $vuln->name,
                    'cve'                => $vuln->cve,
                    'attack_class'       => $vuln->attack_class,
                    'cvss'               => $vuln->cvss,
                    'is_ecommerce'       => (bool) $vuln->is_ecommerce,
                    'vulnerable_version' => $vuln->version,
                    'installed_version'  => $matched['info']['Version'],
                    'is_vulnerable'      => $is_vulnerable_version,
                    'is_active'          => is_plugin_active( $matched['path'] ),
                    'is_installed'       => true,
                );
            } else {
                $detected[] = array(
                    'num'                => $vuln->num,
                    'name'               => $vuln->name,
                    'cve'                => $vuln->cve,
                    'attack_class'       => $vuln->attack_class,
                    'cvss'               => $vuln->cvss,
                    'is_ecommerce'       => (bool) $vuln->is_ecommerce,
                    'vulnerable_version' => $vuln->version,
                    'installed_version'  => null,
                    'is_vulnerable'      => false,
                    'is_active'          => false,
                    'is_installed'       => false,
                );
            }
        }

        return $detected;
    }

    /**
     * Підсумкова статистика встановлених плагінів
     */
    public static function get_installation_stats() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all = get_plugins();
        $active_count = 0;
        foreach ( $all as $path => $info ) {
            if ( is_plugin_active( $path ) ) $active_count++;
        }

        return array(
            'total'    => count( $all ),
            'active'   => $active_count,
            'inactive' => count( $all ) - $active_count,
        );
    }

    /**
     * Параметри стенда для звіту
     */
    public static function get_environment_info() {
        global $wp_version, $wpdb;

        return array(
            'site_url'         => get_site_url(),
            'wp_version'       => $wp_version,
            'php_version'      => PHP_VERSION,
            'mysql_version'    => $wpdb->db_version(),
            'web_server'       => isset( $_SERVER['SERVER_SOFTWARE'] ) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown',
            'os'               => PHP_OS,
            'memory_limit'     => ini_get( 'memory_limit' ),
            'max_execution'    => ini_get( 'max_execution_time' ),
            'active_theme'     => wp_get_theme()->get( 'Name' ),
            'multisite'        => is_multisite() ? 'Yes' : 'No',
        );
    }
}
