<?php
/**
 * Калькулятор метрик
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPDSS_Calculator {

    /**
     * Розрахувати Recall: TP / (TP + FN)
     */
    public static function calculate_recall( $tp, $fn ) {
        if ( $tp + $fn == 0 ) return 0;
        return round( ( $tp / ( $tp + $fn ) ) * 100, 2 );
    }

    /**
     * Розрахувати Precision: TP / (TP + FP)
     */
    public static function calculate_precision( $tp, $fp ) {
        if ( $tp + $fp == 0 ) return 0;
        return round( ( $tp / ( $tp + $fp ) ) * 100, 2 );
    }

    /**
     * Розрахувати F1-score
     */
    public static function calculate_f1( $recall, $precision ) {
        if ( $recall + $precision == 0 ) return 0;
        return round( 2 * ( $recall * $precision ) / ( $recall + $precision ), 2 );
    }

    /**
     * Розрахувати Block Rate: blocked / total_attacks
     */
    public static function calculate_block_rate( $blocked, $total ) {
        if ( $total == 0 ) return 0;
        return round( ( $blocked / $total ) * 100, 2 );
    }

    /**
     * Нормалізація показника продуктивності в діапазон [0, 100]
     * Менше значення CPU/RAM = краще = вище нормоване значення
     *
     * @param float $value     Поточне значення (наприклад, Δ CPU = 9.5%)
     * @param float $worst     Найгірше значення серед усіх плагінів (наприклад, 18%)
     * @param float $best      Найкраще значення (наприклад, 2%)
     */
    public static function normalize_performance( $value, $worst, $best ) {
        if ( $worst == $best ) return 100;
        $score = 100 * ( $worst - $value ) / ( $worst - $best );
        return max( 0, min( 100, round( $score, 2 ) ) );
    }

    /**
     * Розрахувати інтегральний score для DSS
     *
     * @param array $metrics   ['recall' => 100, 'block_rate' => 50, 'perf_score' => 75, 'offline' => 1]
     * @param array $weights   ['recall' => 0.30, 'block' => 0.30, 'perf' => 0.20, 'offline' => 0.20]
     */
    public static function calculate_dss_score( $metrics, $weights ) {
        $score = 0;
        $score += ( $metrics['recall']     / 100 ) * $weights['recall']  * 100;
        $score += ( $metrics['block_rate'] / 100 ) * $weights['block']   * 100;
        $score += ( $metrics['perf_score'] / 100 ) * $weights['perf']    * 100;
        $score += $metrics['offline']             * $weights['offline'] * 100;
        return round( $score, 2 );
    }
}
