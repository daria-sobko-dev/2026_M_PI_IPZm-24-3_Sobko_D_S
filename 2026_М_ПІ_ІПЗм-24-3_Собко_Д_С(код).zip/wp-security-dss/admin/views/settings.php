<?php
/**
 * Налаштування плагіну
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( isset( $_POST['wpdss_reset'] ) && check_admin_referer( 'wpdss_reset_action' ) ) {
    global $wpdb;
    $db = new WPDSS_Database();
    $prefix = $db->get_prefix();
    $wpdb->query( "TRUNCATE TABLE {$prefix}scan_results" );
    $wpdb->query( "TRUNCATE TABLE {$prefix}attack_results" );
    $wpdb->query( "TRUNCATE TABLE {$prefix}performance" );
    $wpdb->query( "TRUNCATE TABLE {$prefix}plugins" );
    $wpdb->query( "TRUNCATE TABLE {$prefix}vulnerabilities" );
    $db->seed_initial_data();
    echo '<div class="notice notice-success"><p>База даних відновлена до початкового стану.</p></div>';
}
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-admin-settings"></span>
            <?php _e( 'Налаштування', 'wp-security-dss' ); ?>
        </h1>
    </div>

    <div class="wpdss-card">
        <h2><?php _e( 'Про плагін', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table">
            <tr><th><?php _e( 'Назва', 'wp-security-dss' ); ?></th><td>WP Security DSS</td></tr>
            <tr><th><?php _e( 'Версія', 'wp-security-dss' ); ?></th><td><?php echo WPDSS_VERSION; ?></td></tr>
            <tr><th><?php _e( 'Автор', 'wp-security-dss' ); ?></th><td>Собко Дарія, ХНУРЕ, ІПЗм-24-3</td></tr>
            <tr><th><?php _e( 'Науковий керівник', 'wp-security-dss' ); ?></th><td>к.т.н., доцент Грудзо І.В.</td></tr>
            <tr><th><?php _e( 'Тип роботи', 'wp-security-dss' ); ?></th><td><?php _e( 'Магістерська науково-дослідницька практика', 'wp-security-dss' ); ?></td></tr>
        </table>
    </div>

    <div class="wpdss-card">
        <h2><?php _e( 'Методологія', 'wp-security-dss' ); ?></h2>
        <p><?php _e( 'Тестування проведено за двохрівневою методологією:', 'wp-security-dss' ); ?></p>
        <ol>
            <li><strong><?php _e( 'Пасивне сканування', 'wp-security-dss' ); ?>:</strong>
                <?php _e( 'кожен з 5 захисних плагінів сканував сайт з 12 преднамеренно вразливими плагінами. Розраховувався Recall = TP / (TP + FN).', 'wp-security-dss' ); ?>
            </li>
            <li><strong><?php _e( 'Активні атаки', 'wp-security-dss' ); ?>:</strong>
                <?php _e( 'проти кожного захисного плагіну проведено 6 типових атак (XSS, SQLi, Brute Force, File Upload, Parameter Tampering, CSRF). Розраховувався Block Rate = Block / Total.', 'wp-security-dss' ); ?>
            </li>
            <li><strong><?php _e( 'DSS-ранжування', 'wp-security-dss' ); ?>:</strong>
                <?php _e( 'багатокритеріальна оцінка за 4 параметрами з ваговими коефіцієнтами користувача.', 'wp-security-dss' ); ?>
            </li>
        </ol>
    </div>

    <div class="wpdss-card">
        <h2><?php _e( 'Технічний стек', 'wp-security-dss' ); ?></h2>
        <ul>
            <li>PHP 7.4+ / WordPress 6.0+</li>
            <li>MySQL для зберігання результатів (5 таблиць wp_wpdss_*)</li>
            <li>Chart.js 4.4 для візуалізації</li>
            <li>jQuery для AJAX</li>
        </ul>
    </div>

    <div class="wpdss-card">
        <h2 style="color: #dc2626;"><?php _e( 'Скидання бази даних', 'wp-security-dss' ); ?></h2>
        <p><?php _e( 'Видалить ВСІ результати і відновить до початкового стану (5 плагінів + 12 вразливих + базові результати експерименту).', 'wp-security-dss' ); ?></p>
        <form method="post" onsubmit="return confirm('<?php _e( 'Ви впевнені?', 'wp-security-dss' ); ?>');">
            <?php wp_nonce_field( 'wpdss_reset_action' ); ?>
            <input type="hidden" name="wpdss_reset" value="1">
            <button type="submit" class="button button-secondary" style="color: #dc2626; border-color: #dc2626;">
                <?php _e( 'Скинути базу до початкової', 'wp-security-dss' ); ?>
            </button>
        </form>
    </div>
</div>
