<?php
/**
 * Сторінка DSS-рекомендацій зі слайдерами
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$presets = WPDSS_Recommendation::get_preset_scenarios();
$default_weights = $presets['balanced']['weights'];
$initial_ranking = WPDSS_Recommendation::rank_plugins( $default_weights );
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-awards"></span>
            <?php _e( 'DSS Рекомендації', 'wp-security-dss' ); ?>
        </h1>
        <p class="wpdss-subtitle">
            <?php _e( 'Налаштуйте вагові коефіцієнти критеріїв — отримайте персональну рекомендацію', 'wp-security-dss' ); ?>
        </p>
    </div>

    <div class="wpdss-dss-layout">
        <!-- Ліва панель: слайдери і пресети -->
        <div class="wpdss-dss-controls">

            <div class="wpdss-card">
                <h2><?php _e( 'Готові сценарії', 'wp-security-dss' ); ?></h2>
                <div class="wpdss-presets">
                    <?php foreach ( $presets as $key => $preset ) : ?>
                    <button class="wpdss-preset-btn" data-preset="<?php echo esc_attr( $key ); ?>"
                            data-recall="<?php echo $preset['weights']['recall']; ?>"
                            data-block="<?php echo $preset['weights']['block']; ?>"
                            data-perf="<?php echo $preset['weights']['perf']; ?>"
                            data-offline="<?php echo $preset['weights']['offline']; ?>">
                        <strong><?php echo esc_html( $preset['label'] ); ?></strong>
                        <small><?php echo esc_html( $preset['description'] ); ?></small>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="wpdss-card">
                <h2><?php _e( 'Або налаштуйте вручну', 'wp-security-dss' ); ?></h2>

                <div class="wpdss-slider-group">
                    <label>
                        <span class="wpdss-slider-icon" style="color: #16a34a;">🔍</span>
                        <strong><?php _e( 'Виявлення вразливостей (Recall)', 'wp-security-dss' ); ?></strong>
                        <span class="wpdss-slider-value" id="value_recall">25%</span>
                    </label>
                    <input type="range" id="slider_recall" min="0" max="100" value="25">
                    <small><?php _e( 'Наскільки важливо, щоб плагін знаходив всі CVE', 'wp-security-dss' ); ?></small>
                </div>

                <div class="wpdss-slider-group">
                    <label>
                        <span class="wpdss-slider-icon" style="color: #dc2626;">🛡️</span>
                        <strong><?php _e( 'Активний захист (Block Rate)', 'wp-security-dss' ); ?></strong>
                        <span class="wpdss-slider-value" id="value_block">25%</span>
                    </label>
                    <input type="range" id="slider_block" min="0" max="100" value="25">
                    <small><?php _e( 'Наскільки важливо блокувати реальні атаки', 'wp-security-dss' ); ?></small>
                </div>

                <div class="wpdss-slider-group">
                    <label>
                        <span class="wpdss-slider-icon" style="color: #f59e0b;">⚡</span>
                        <strong><?php _e( 'Продуктивність (low CPU/RAM)', 'wp-security-dss' ); ?></strong>
                        <span class="wpdss-slider-value" id="value_perf">25%</span>
                    </label>
                    <input type="range" id="slider_perf" min="0" max="100" value="25">
                    <small><?php _e( 'Наскільки важливо мінімальне навантаження', 'wp-security-dss' ); ?></small>
                </div>

                <div class="wpdss-slider-group">
                    <label>
                        <span class="wpdss-slider-icon" style="color: #0369a1;">🌐</span>
                        <strong><?php _e( 'Автономність (Offline)', 'wp-security-dss' ); ?></strong>
                        <span class="wpdss-slider-value" id="value_offline">25%</span>
                    </label>
                    <input type="range" id="slider_offline" min="0" max="100" value="25">
                    <small><?php _e( 'Робота без хмарних сервісів', 'wp-security-dss' ); ?></small>
                </div>

                <div class="wpdss-weights-total">
                    <?php _e( 'Сума ваг:', 'wp-security-dss' ); ?>
                    <strong id="weights_total">100%</strong>
                    <span class="wpdss-weights-status" id="weights_status">✓</span>
                </div>

                <button id="recalculate_btn" class="button button-primary button-large" style="width: 100%; margin-top: 12px;">
                    <span class="dashicons dashicons-update"></span>
                    <?php _e( 'Перерахувати рейтинг', 'wp-security-dss' ); ?>
                </button>
            </div>
        </div>

        <!-- Права панель: результати -->
        <div class="wpdss-dss-results">
            <div class="wpdss-card">
                <h2><?php _e( 'Рекомендація', 'wp-security-dss' ); ?></h2>
                <div id="ranking_results">
                    <?php foreach ( $initial_ranking as $i => $r ) : ?>
                    <div class="wpdss-rank-row wpdss-rank-<?php echo esc_attr( $r['recommendation'] ); ?>">
                        <div class="wpdss-rank-number">
                            <?php if ( $r['rank'] == 1 ) echo '🥇'; ?>
                            <?php if ( $r['rank'] == 2 ) echo '🥈'; ?>
                            <?php if ( $r['rank'] == 3 ) echo '🥉'; ?>
                            <?php if ( $r['rank'] > 3 ) echo '#' . $r['rank']; ?>
                        </div>
                        <div class="wpdss-rank-info">
                            <div class="wpdss-rank-name" style="color: <?php echo esc_attr( $r['color'] ); ?>;">
                                <?php echo esc_html( $r['code'] ); ?> — <?php echo esc_html( $r['name'] ); ?>
                            </div>
                            <div class="wpdss-rank-meta">
                                <small>Recall: <?php echo $r['recall']; ?>%</small>
                                <small>Block: <?php echo $r['block_rate']; ?>%</small>
                                <small>Perf: <?php echo $r['perf_score']; ?></small>
                                <small><?php echo $r['offline'] ? 'Offline ✓' : 'Cloud'; ?></small>
                            </div>
                        </div>
                        <div class="wpdss-rank-score">
                            <strong><?php echo $r['score']; ?></strong>
                            <small><?php _e( 'балів', 'wp-security-dss' ); ?></small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="wpdss-card">
                <h2><?php _e( 'Графік оцінок', 'wp-security-dss' ); ?></h2>
                <div style="height: 400px;"><canvas id="chartScores"></canvas></div>
            </div>
        </div>
    </div>
</div>
