<?php
/**
 * База всіх результатів експерименту
 * v2.0 — 51 уразливий плагін + 11 захисних + реальний статус з адмінки
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$db = new WPDSS_Database();
$prefix = $db->get_prefix();

$plugins = $db->get_all_plugins_with_metrics();
$vulnerabilities = $db->get_all_vulnerabilities();
$matrix = $db->get_detection_matrix();

// Реальний статус уразливих з адмінки
$installed_vulnerable = WPDSS_Detector::detect_vulnerable_plugins();
$status_by_num = array();
foreach ( $installed_vulnerable as $v ) {
    $status_by_num[ $v['num'] ] = $v;
}
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-database-view"></span>
            <?php _e( 'База результатів експерименту', 'wp-security-dss' ); ?>
        </h1>
        <p class="wpdss-subtitle">
            <?php _e( 'Повна доказова база дослідження: 51 уразливий плагін × 11 плагінів безпеки', 'wp-security-dss' ); ?>
        </p>
    </div>

    <!-- Таблиця Д.1 — 51 уразливий плагін -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.1 — Перелік уразливих плагінів тестового стенду', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Обсяг вибірки обґрунтовано формулою Кохрена для рівня довіри 90% (n=51, з населення 2500+). Стовпець "Статус" — поточний стан в адмінці WP.', 'wp-security-dss' ); ?></p>
        <div style="max-height: 600px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 4px;">
        <table class="wpdss-table wpdss-table-striped">
            <thead style="position: sticky; top: 0; background: #1F4E79; color: white; z-index: 1;">
                <tr>
                    <th>№</th>
                    <th>Назва плагіна</th>
                    <th>Версія</th>
                    <th>CVE</th>
                    <th>Тип вразливості</th>
                    <th>CVSS</th>
                    <th>E-com</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $vulnerabilities as $v ) : 
                    $cvss_class = $v->cvss >= 9.0 ? 'bad' : ( $v->cvss >= 7.0 ? 'medium' : 'good' );
                    $status = isset( $status_by_num[ $v->num ] ) ? $status_by_num[ $v->num ] : null;
                ?>
                <tr>
                    <td><strong><?php echo esc_html( $v->num ); ?></strong></td>
                    <td><?php echo esc_html( $v->name ); ?></td>
                    <td>v<?php echo esc_html( $v->version ); ?></td>
                    <td><small><?php echo esc_html( $v->cve ); ?></small></td>
                    <td><?php echo esc_html( $v->attack_class ); ?></td>
                    <td><span class="wpdss-pill <?php echo $cvss_class; ?>"><?php echo esc_html( $v->cvss ); ?></span></td>
                    <td><?php echo $v->is_ecommerce ? '<strong style="color:#16a34a;">✓</strong>' : '<span style="color:#94a3b8;">—</span>'; ?></td>
                    <td>
                        <?php if ( $status && $status['is_active'] ) : ?>
                            <span style="color:#16a34a;font-weight:bold;">●&nbsp;Активний</span>
                            <?php if ( $status['installed_version'] !== $v->version ) : ?>
                                <small style="color:#94a3b8;display:block;">v<?php echo esc_html( $status['installed_version'] ); ?></small>
                            <?php endif; ?>
                        <?php elseif ( $status && $status['is_installed'] ) : ?>
                            <span style="color:#f59e0b;">○ Inactive</span>
                        <?php else : ?>
                            <span style="color:#94a3b8;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- Таблиця Д.2 — Матриця детекції -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.2 — Матриця детекції за типами загроз', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Виявлено / Загальна кількість по класах атак', 'wp-security-dss' ); ?></p>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін безпеки</th>
                    <th>XSS<br><small>(19)</small></th>
                    <th>SQLi<br><small>(8)</small></th>
                    <th>RCE<br><small>(7)</small></th>
                    <th>CSRF<br><small>(5)</small></th>
                    <th>Auth Bypass<br><small>(5)</small></th>
                    <th>File Incl.<br><small>(4)</small></th>
                    <th>Інші<br><small>(3)</small></th>
                    <th>Всього<br><small>(51)</small></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $matrix as $m ) : 
                    $cells = array(
                        array( $m->detected_xss, 19 ),
                        array( $m->detected_sqli, 8 ),
                        array( $m->detected_rce, 7 ),
                        array( $m->detected_csrf, 5 ),
                        array( $m->detected_auth, 5 ),
                        array( $m->detected_file, 4 ),
                        array( $m->detected_other, 3 ),
                    );
                ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $m->color ); ?>;"><?php echo esc_html( $m->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $m->name ); ?></strong></td>
                    <?php foreach ( $cells as $cell ) : 
                        $ratio = $cell[1] > 0 ? $cell[0] / $cell[1] : 0;
                        $cls = $ratio >= 0.8 ? 'good' : ( $ratio >= 0.5 ? 'medium' : 'bad' );
                    ?>
                    <td><span class="wpdss-pill <?php echo $cls; ?>"><?php echo $cell[0]; ?>/<?php echo $cell[1]; ?></span></td>
                    <?php endforeach; ?>
                    <td><strong><?php echo $m->detected_total; ?>/51</strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Таблиця Д.3 — Продуктивність -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.3 — Результати вимірювання продуктивності', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін</th>
                    <th>Виявлено</th>
                    <th>Recall %</th>
                    <th>FP Rate %</th>
                    <th>FP шт.</th>
                    <th>Час відгуку, с</th>
                    <th>CPU, %</th>
                    <th>RAM, МБ</th>
                    <th>Час скан., хв</th>
                    <th>Моніт. %</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $plugins as $p ) : ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $p->color ); ?>;"><?php echo esc_html( $p->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $p->name ); ?></strong></td>
                    <td><?php echo $p->detected_count; ?></td>
                    <td><span class="wpdss-pill <?php echo $p->recall >= 80 ? 'good' : ( $p->recall >= 40 ? 'medium' : 'bad' ); ?>"><?php echo $p->recall; ?></span></td>
                    <td><?php echo $p->fp_rate; ?></td>
                    <td><?php echo $p->fp_count; ?></td>
                    <td><?php echo $p->response_time; ?></td>
                    <td>+<?php echo $p->cpu_delta; ?></td>
                    <td>+<?php echo $p->ram_delta; ?></td>
                    <td><?php echo $p->scan_time; ?></td>
                    <td><?php echo $p->monitoring; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Таблиця Д.4 — Активні атаки -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.4 — Результати тестування активних атак', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін безпеки</th>
                    <th>Brute Force</th>
                    <th>SQLi WAF</th>
                    <th>XSS WAF</th>
                    <th>CSRF захист</th>
                    <th>EICAR детекція</th>
                    <th>Бал</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $plugins as $p ) : 
                    $cells = array( $p->brute_force, $p->sqli_waf, $p->xss_waf, $p->csrf_protect, $p->eicar_detect );
                ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $p->color ); ?>;"><?php echo esc_html( $p->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $p->name ); ?></strong></td>
                    <?php foreach ( $cells as $val ) :
                        $cls = 'bad';
                        if ( strpos( $val, 'Так' ) === 0 ) $cls = 'good';
                        elseif ( $val === 'Частково' ) $cls = 'medium';
                    ?>
                    <td><span class="wpdss-pill <?php echo $cls; ?>"><?php echo esc_html( $val ); ?></span></td>
                    <?php endforeach; ?>
                    <td><strong><?php echo esc_html( $p->total_score ); ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Підсумкова статистика -->
    <div class="wpdss-card">
        <h2><?php _e( 'Підсумкова статистика', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table">
            <tr>
                <th><?php _e( 'Загальна кількість тестів', 'wp-security-dss' ); ?></th>
                <td><strong>51 уразливих × 11 захисних = 561 точка детекції</strong></td>
            </tr>
            <tr>
                <th><?php _e( 'Активних атак', 'wp-security-dss' ); ?></th>
                <td><strong>5 типів × 11 захисних = 55 тестів атак</strong></td>
            </tr>
            <tr>
                <th><?php _e( 'E-commerce плагінів у вибірці', 'wp-security-dss' ); ?></th>
                <td>
                    <?php
                    $ecom_count = 0;
                    foreach ( $vulnerabilities as $v ) if ( $v->is_ecommerce ) $ecom_count++;
                    echo $ecom_count;
                    ?> із 51
                </td>
            </tr>
            <tr>
                <th><?php _e( 'Середній CVSS', 'wp-security-dss' ); ?></th>
                <td>
                    <?php
                    $sum_cvss = 0;
                    foreach ( $vulnerabilities as $v ) $sum_cvss += $v->cvss;
                    echo round( $sum_cvss / count( $vulnerabilities ), 1 );
                    ?>
                </td>
            </tr>
            <tr>
                <th><?php _e( 'Уразливих плагінів встановлено в адмінці', 'wp-security-dss' ); ?></th>
                <td>
                    <?php
                    $installed = 0;
                    foreach ( $installed_vulnerable as $v ) if ( $v['is_installed'] ) $installed++;
                    echo "<strong>$installed</strong> із 51";
                    ?>
                </td>
            </tr>
        </table>
    </div>
</div>
