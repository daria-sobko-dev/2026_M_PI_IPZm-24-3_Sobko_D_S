<?php
/**
 * Сторінка порівняння плагінів з графіками
 * v2.0 — 11 плагінів безпеки + матриця детекції за типами атак
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$db = new WPDSS_Database();
$plugins = $db->get_all_plugins_with_metrics();
$matrix = $db->get_detection_matrix();

// Готуємо дані для графіків
$labels = array();
$recalls = array();
$blocks = array();
$cpus = array();
$rams = array();
$colors = array();
$response_times = array();
$fp_rates = array();
$scan_times = array();
$monitoring = array();

foreach ( $plugins as $p ) {
    $labels[] = $p->code . ' ' . $p->name;
    $recalls[] = $p->recall;
    $blocks[] = $p->block_rate;
    $cpus[] = $p->cpu_delta;
    $rams[] = $p->ram_delta;
    $colors[] = $p->color;
    $response_times[] = $p->response_time;
    $fp_rates[] = $p->fp_rate;
    $scan_times[] = $p->scan_time;
    $monitoring[] = $p->monitoring;
}
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-chart-bar"></span>
            <?php _e( 'Порівняння плагінів безпеки', 'wp-security-dss' ); ?>
        </h1>
        <p class="wpdss-subtitle"><?php _e( 'Візуалізація результатів експерименту: 11 захисних плагінів × 51 уразливих × 6 атак', 'wp-security-dss' ); ?></p>
    </div>

    <!-- Графік 1: Recall vs Block Rate -->
    <div class="wpdss-card">
        <h2><?php _e( 'Recall vs Block Rate', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Виявлення CVE (пасивне сканування) і блокування атак (активне тестування)', 'wp-security-dss' ); ?></p>
        <div style="height: 450px;"><canvas id="chartRecallBlock"></canvas></div>
    </div>

    <!-- Графік 2: Продуктивність -->
    <div class="wpdss-card">
        <h2><?php _e( 'Δ CPU та Δ RAM', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Навантаження кожного плагіну на ресурси сервера', 'wp-security-dss' ); ?></p>
        <div style="height: 450px;"><canvas id="chartPerformance"></canvas></div>
    </div>

    <!-- Графік 3: Radar -->
    <div class="wpdss-card">
        <h2><?php _e( 'Радар-діаграма (всі метрики)', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Інтегральне порівняння за 5 критеріями', 'wp-security-dss' ); ?></p>
        <div style="height: 600px;"><canvas id="chartRadar"></canvas></div>
    </div>

    <!-- Таблиця Д.2: Матриця детекції за типами загроз -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.2 — Матриця детекції за типами загроз', 'wp-security-dss' ); ?></h2>
        <p class="description"><?php _e( 'Кількість виявлених уразливостей по класам атак (з 51 загального)', 'wp-security-dss' ); ?></p>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін безпеки</th>
                    <th>XSS (19)</th>
                    <th>SQLi (8)</th>
                    <th>RCE (7)</th>
                    <th>CSRF (5)</th>
                    <th>Auth Bypass (5)</th>
                    <th>File Incl. (4)</th>
                    <th>Інші (3)</th>
                    <th>Всього (51)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $matrix as $m ) : 
                    $cells = array(
                        array( $m->detected_xss, 19 ),
                        array( $m->detected_sqli, 8 ),
                        array( $m->detected_rce, 7 ),
                        array( $m->detected_csrf, 5 ),
                        array( $m->detected_auth, 5 ),
                        array( $m->detected_file, 4 ),
                        array( $m->detected_other, 3 ),
                    );
                ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $m->color ); ?>;"><?php echo esc_html( $m->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $m->name ); ?></strong></td>
                    <?php foreach ( $cells as $cell ) : 
                        $ratio = $cell[1] > 0 ? $cell[0] / $cell[1] : 0;
                        $cls = $ratio >= 0.8 ? 'good' : ( $ratio >= 0.5 ? 'medium' : 'bad' );
                    ?>
                    <td><span class="wpdss-pill <?php echo $cls; ?>"><?php echo $cell[0]; ?>/<?php echo $cell[1]; ?></span></td>
                    <?php endforeach; ?>
                    <td><strong><?php echo $m->detected_total; ?>/51</strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Таблиця Д.3: Продуктивність -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.3 — Результати вимірювання продуктивності', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін</th>
                    <th>Виявлено (з 51)</th>
                    <th>Recall, %</th>
                    <th>FP Rate, %</th>
                    <th>FP (шт.)</th>
                    <th>Час відгуку, с</th>
                    <th>CPU, %</th>
                    <th>RAM, МБ</th>
                    <th>Час скан., хв</th>
                    <th>Моніт., %</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $plugins as $p ) : ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $p->color ); ?>;"><?php echo esc_html( $p->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $p->name ); ?></strong></td>
                    <td><?php echo $p->detected_count; ?></td>
                    <td><span class="wpdss-pill <?php echo $p->recall >= 80 ? 'good' : ( $p->recall >= 40 ? 'medium' : 'bad' ); ?>"><?php echo $p->recall; ?></span></td>
                    <td><?php echo $p->fp_rate; ?></td>
                    <td><?php echo $p->fp_count; ?></td>
                    <td><?php echo $p->response_time; ?></td>
                    <td>+<?php echo $p->cpu_delta; ?></td>
                    <td>+<?php echo $p->ram_delta; ?></td>
                    <td><?php echo $p->scan_time; ?></td>
                    <td><?php echo $p->monitoring; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Таблиця Д.4: Активні атаки -->
    <div class="wpdss-card">
        <h2><?php _e( 'Таблиця Д.4 — Результати активних атак (WAF, brute force, malware)', 'wp-security-dss' ); ?></h2>
        <table class="wpdss-table wpdss-table-striped">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Плагін безпеки</th>
                    <th>Brute Force блокування</th>
                    <th>SQLi WAF</th>
                    <th>XSS WAF</th>
                    <th>CSRF захист</th>
                    <th>EICAR детекція</th>
                    <th>Загальний бал</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $plugins as $p ) : 
                    $cells = array(
                        $p->brute_force,
                        $p->sqli_waf,
                        $p->xss_waf,
                        $p->csrf_protect,
                        $p->eicar_detect,
                    );
                ?>
                <tr>
                    <td><strong style="color: <?php echo esc_attr( $p->color ); ?>;"><?php echo esc_html( $p->code ); ?></strong></td>
                    <td><strong><?php echo esc_html( $p->name ); ?></strong></td>
                    <?php foreach ( $cells as $val ) :
                        $cls = 'bad';
                        if ( strpos( $val, 'Так' ) === 0 ) $cls = 'good';
                        elseif ( $val === 'Частково' ) $cls = 'medium';
                    ?>
                    <td><span class="wpdss-pill <?php echo $cls; ?>"><?php echo esc_html( $val ); ?></span></td>
                    <?php endforeach; ?>
                    <td><strong><?php echo esc_html( $p->total_score ); ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
window.wpdssChartData = {
    labels:  <?php echo wp_json_encode( $labels ); ?>,
    recalls: <?php echo wp_json_encode( $recalls ); ?>,
    blocks:  <?php echo wp_json_encode( $blocks ); ?>,
    cpus:    <?php echo wp_json_encode( $cpus ); ?>,
    rams:    <?php echo wp_json_encode( $rams ); ?>,
    colors:  <?php echo wp_json_encode( $colors ); ?>,
    response_times: <?php echo wp_json_encode( $response_times ); ?>,
    fp_rates: <?php echo wp_json_encode( $fp_rates ); ?>,
    monitoring: <?php echo wp_json_encode( $monitoring ); ?>
};
</script>
