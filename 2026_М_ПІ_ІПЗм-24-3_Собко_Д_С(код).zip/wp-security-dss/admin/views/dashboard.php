<?php
/**
 * Сторінка Dashboard — v2.0
 * 11 плагінів безпеки + 51 уразливий + реальний статус з адмінки
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$db = new WPDSS_Database();
$plugins = $db->get_all_plugins_with_metrics();
$env = WPDSS_Detector::get_environment_info();
$installed_security = WPDSS_Detector::detect_security_plugins();
$installed_vulnerable = WPDSS_Detector::detect_vulnerable_plugins();
$stats = WPDSS_Detector::get_installation_stats();

// Загальні метрики
$avg_recall = 0;
$avg_block = 0;
foreach ( $plugins as $p ) {
    $avg_recall += $p->recall;
    $avg_block += $p->block_rate;
}
$avg_recall = count( $plugins ) > 0 ? round( $avg_recall / count( $plugins ), 1 ) : 0;
$avg_block = count( $plugins ) > 0 ? round( $avg_block / count( $plugins ), 1 ) : 0;

// Активний плагін
$active_security = null;
foreach ( $installed_security as $s ) {
    if ( $s['is_active'] ) { $active_security = $s; break; }
}

// Статистика
$installed_count = 0;
$inactive_security_count = 0;
foreach ( $installed_security as $s ) {
    if ( $s['is_installed'] ) {
        $installed_count++;
        if ( ! $s['is_active'] ) $inactive_security_count++;
    }
}

// Лідер за Recall
$top_recall = null;
foreach ( $plugins as $p ) {
    if ( ! $top_recall || $p->recall > $top_recall->recall ) $top_recall = $p;
}

// Уразливі плагіни в адмінці (з реальних даних)
$vulnerable_installed = 0;
$vulnerable_active = 0;
foreach ( $installed_vulnerable as $v ) {
    if ( $v['is_installed'] ) $vulnerable_installed++;
    if ( $v['is_active'] ) $vulnerable_active++;
}
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-shield-alt"></span>
            <?php _e( 'Security DSS — Dashboard', 'wp-security-dss' ); ?>
        </h1>
        <p class="wpdss-subtitle">
            <?php _e( 'Система підтримки прийняття рішень для вибору оптимального плагіну безпеки WordPress', 'wp-security-dss' ); ?>
            <br><em>Магістерська робота</em>
        </p>
    </div>

    <!-- Загальні метрики -->
    <div class="wpdss-summary-cards">
        <div class="wpdss-summary-card">
            <div class="wpdss-summary-icon" style="background: #e0f2fe;">
                <span class="dashicons dashicons-search" style="color: #0369a1;"></span>
            </div>
            <div class="wpdss-summary-info">
                <div class="wpdss-summary-label"><?php _e( 'Плагінів безпеки', 'wp-security-dss' ); ?></div>
                <div class="wpdss-summary-value">11 <small style="opacity:0.7;">досліджено</small></div>
            </div>
        </div>

        <div class="wpdss-summary-card">
            <div class="wpdss-summary-icon" style="background: #fee2e2;">
                <span class="dashicons dashicons-warning" style="color: #dc2626;"></span>
            </div>
            <div class="wpdss-summary-info">
                <div class="wpdss-summary-label"><?php _e( 'Уразливих плагінів', 'wp-security-dss' ); ?></div>
                <div class="wpdss-summary-value">51 <small style="opacity:0.7;">у вибірці</small></div>
            </div>
        </div>

        <div class="wpdss-summary-card">
            <div class="wpdss-summary-icon" style="background: #dcfce7;">
                <span class="dashicons dashicons-yes-alt" style="color: #16a34a;"></span>
            </div>
            <div class="wpdss-summary-info">
                <div class="wpdss-summary-label"><?php _e( 'Середній Recall', 'wp-security-dss' ); ?></div>
                <div class="wpdss-summary-value"><?php echo $avg_recall; ?>%</div>
            </div>
        </div>

        <div class="wpdss-summary-card">
            <div class="wpdss-summary-icon" style="background: #fef3c7;">
                <span class="dashicons dashicons-shield" style="color: #d97706;"></span>
            </div>
            <div class="wpdss-summary-info">
                <div class="wpdss-summary-label"><?php _e( 'Середній Block Rate', 'wp-security-dss' ); ?></div>
                <div class="wpdss-summary-value"><?php echo $avg_block; ?>%</div>
            </div>
        </div>
    </div>

    <!-- Реальна статистика з адмінки WP -->
    <div class="wpdss-card" style="background: #f0f9ff; border-left: 4px solid #0369a1;">
        <h2 style="margin-top:0;">
            <span class="dashicons dashicons-admin-plugins"></span>
            <?php _e( 'Реальний стан плагінів у тестовому стенді', 'wp-security-dss' ); ?>
        </h2>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-top: 12px;">
            <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: bold; color: #0369a1;"><?php echo $stats['total']; ?></div>
                <div style="font-size: 13px; color: #475569;"><?php _e( 'Всього плагінів', 'wp-security-dss' ); ?></div>
            </div>
            <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: bold; color: #16a34a;"><?php echo $stats['active']; ?></div>
                <div style="font-size: 13px; color: #475569;"><?php _e( 'Активних', 'wp-security-dss' ); ?></div>
            </div>
            <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: bold; color: #f59e0b;"><?php echo $stats['inactive']; ?></div>
                <div style="font-size: 13px; color: #475569;"><?php _e( 'Неактивних', 'wp-security-dss' ); ?></div>
            </div>
            <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: bold; color: #dc2626;"><?php echo $installed_count; ?>/11</div>
                <div style="font-size: 13px; color: #475569;"><?php _e( 'Плагінів безпеки', 'wp-security-dss' ); ?></div>
            </div>
        </div>
        <p style="margin: 12px 0 0 0; font-size: 13px; color: #475569;">
            <?php echo sprintf( __( 'З 11 досліджуваних плагінів безпеки: <strong>%d встановлено</strong>, з них <strong>%d неактивних</strong> (тестуються по черзі для уникнення конфліктів між WAF).', 'wp-security-dss' ), $installed_count, $inactive_security_count ); ?>
        </p>
    </div>

    <!-- Активний захисний плагін -->
    <?php if ( $active_security ) : ?>
    <div class="wpdss-notice wpdss-notice-info">
        <span class="dashicons dashicons-shield-alt"></span>
        <strong><?php _e( 'Активний захисний плагін:', 'wp-security-dss' ); ?></strong>
        <?php echo esc_html( $active_security['name'] ); ?>
        v<?php echo esc_html( $active_security['installed_version'] ); ?>
        (<?php echo esc_html( $active_security['code'] ); ?>)
    </div>
    <?php else : ?>
    <div class="wpdss-notice wpdss-notice-warning">
        <span class="dashicons dashicons-warning"></span>
        <strong><?php _e( 'Стан:', 'wp-security-dss' ); ?></strong>
        <?php _e( 'Жоден плагін безпеки не активний (це нормально між сесіями тестування)', 'wp-security-dss' ); ?>
    </div>
    <?php endif; ?>

    <?php if ( $top_recall ) : ?>
    <div class="wpdss-notice wpdss-notice-success">
        <span class="dashicons dashicons-awards"></span>
        <strong><?php _e( 'Лідер за Recall:', 'wp-security-dss' ); ?></strong>
        <?php echo esc_html( $top_recall->name ); ?> —
        <?php echo $top_recall->recall; ?>% (<?php echo $top_recall->detected_count; ?>/51 уразливостей)
    </div>
    <?php endif; ?>

    <!-- Карточки плагінів -->
    <h2 class="wpdss-section-title"><?php _e( '11 досліджуваних плагінів безпеки', 'wp-security-dss' ); ?></h2>

    <div class="wpdss-plugin-grid">
        <?php foreach ( $plugins as $plugin ) :
            // Знаходимо статус встановлення
            $detected_status = null;
            foreach ( $installed_security as $s ) {
                if ( $s['code'] === $plugin->code ) { $detected_status = $s; break; }
            }
            $is_installed = $detected_status && $detected_status['is_installed'];
            $is_active = $detected_status && $detected_status['is_active'];
            $real_version = $detected_status ? $detected_status['installed_version'] : null;
        ?>
        <div class="wpdss-plugin-card" style="border-top: 4px solid <?php echo esc_attr( $plugin->color ); ?>; <?php echo $is_active ? 'box-shadow: 0 0 0 2px #16a34a;' : ''; ?>">
            <div class="wpdss-plugin-card-header">
                <div class="wpdss-plugin-code" style="background: <?php echo esc_attr( $plugin->color ); ?>;">
                    <?php echo esc_html( $plugin->code ); ?>
                </div>
                <div class="wpdss-plugin-name">
                    <h3><?php echo esc_html( $plugin->name ); ?></h3>
                    <span class="wpdss-plugin-version">
                        v<?php echo esc_html( $plugin->version ); ?>
                        <?php if ( $real_version && $real_version !== $plugin->version ) : ?>
                            <small style="color:#94a3b8;">(встановлено v<?php echo esc_html( $real_version ); ?>)</small>
                        <?php endif; ?>
                        · <?php echo esc_html( $plugin->installs ); ?>
                    </span>
                </div>
                <?php if ( $is_active ) : ?>
                <span class="wpdss-badge wpdss-badge-active" style="background:#16a34a;color:white;">●&nbsp;<?php _e( 'Активний', 'wp-security-dss' ); ?></span>
                <?php elseif ( $is_installed ) : ?>
                <span class="wpdss-badge wpdss-badge-installed" style="background:#f59e0b;color:white;"><?php _e( 'Inactive', 'wp-security-dss' ); ?></span>
                <?php else : ?>
                <span class="wpdss-badge" style="background:#94a3b8;color:white;"><?php _e( 'Не встан.', 'wp-security-dss' ); ?></span>
                <?php endif; ?>
            </div>

            <div class="wpdss-plugin-arch">
                <span class="dashicons dashicons-admin-network"></span>
                <?php echo esc_html( $plugin->architecture ); ?>
            </div>

            <!-- Метрики -->
            <div class="wpdss-metrics">
                <div class="wpdss-metric">
                    <div class="wpdss-metric-label">Recall</div>
                    <div class="wpdss-metric-circle <?php echo $plugin->recall >= 80 ? 'good' : ( $plugin->recall >= 40 ? 'medium' : 'bad' ); ?>">
                        <?php echo $plugin->recall; ?>%
                    </div>
                    <div class="wpdss-metric-detail"><?php echo $plugin->detected_count; ?>/51</div>
                </div>

                <div class="wpdss-metric">
                    <div class="wpdss-metric-label">Block Rate</div>
                    <div class="wpdss-metric-circle <?php echo $plugin->block_rate >= 50 ? 'good' : ( $plugin->block_rate >= 25 ? 'medium' : 'bad' ); ?>">
                        <?php echo $plugin->block_rate; ?>%
                    </div>
                    <div class="wpdss-metric-detail"><?php echo esc_html( $plugin->total_score ); ?></div>
                </div>
            </div>

            <!-- Продуктивність -->
            <div class="wpdss-perf">
                <div class="wpdss-perf-item">
                    <span class="dashicons dashicons-performance"></span>
                    <span>CPU: +<?php echo $plugin->cpu_delta; ?>%</span>
                </div>
                <div class="wpdss-perf-item">
                    <span class="dashicons dashicons-database"></span>
                    <span>RAM: +<?php echo $plugin->ram_delta; ?>MB</span>
                </div>
                <div class="wpdss-perf-item">
                    <span class="dashicons dashicons-clock"></span>
                    <span><?php echo $plugin->response_time; ?>с</span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Уразливі плагіни в адмінці -->
    <h2 class="wpdss-section-title"><?php _e( 'Уразливі плагіни на стенді', 'wp-security-dss' ); ?></h2>
    <div class="wpdss-card">
        <table class="wpdss-table">
            <tr>
                <th><?php _e( 'Уразливих плагінів у Таблиці Д.1', 'wp-security-dss' ); ?></th>
                <td><strong>51</strong></td>
            </tr>
            <tr>
                <th><?php _e( 'З них встановлено в адмінці', 'wp-security-dss' ); ?></th>
                <td><strong><?php echo $vulnerable_installed; ?></strong></td>
            </tr>
            <tr>
                <th><?php _e( 'З них активних', 'wp-security-dss' ); ?></th>
                <td><strong><?php echo $vulnerable_active; ?></strong></td>
            </tr>
        </table>
        <p>
            <a href="<?php echo admin_url( 'admin.php?page=wpdss-database' ); ?>" class="button">
                <?php _e( 'Переглянути повну Таблицю Д.1 →', 'wp-security-dss' ); ?>
            </a>
        </p>
    </div>

    <!-- Параметри стенду -->
    <h2 class="wpdss-section-title"><?php _e( 'Параметри тестового стенду', 'wp-security-dss' ); ?></h2>
    <table class="wpdss-table">
        <tr><th><?php _e( 'URL', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['site_url'] ); ?></td></tr>
        <tr><th><?php _e( 'WordPress', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['wp_version'] ); ?></td></tr>
        <tr><th><?php _e( 'PHP', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['php_version'] ); ?></td></tr>
        <tr><th><?php _e( 'MySQL', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['mysql_version'] ); ?></td></tr>
        <tr><th><?php _e( 'Web сервер', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['web_server'] ); ?></td></tr>
        <tr><th><?php _e( 'Тема', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['active_theme'] ); ?></td></tr>
        <tr><th><?php _e( 'Memory Limit', 'wp-security-dss' ); ?></th><td><?php echo esc_html( $env['memory_limit'] ); ?></td></tr>
    </table>

    <!-- Кнопки дій -->
    <div class="wpdss-actions">
        <a href="<?php echo admin_url( 'admin.php?page=wpdss-comparison' ); ?>" class="button button-primary button-large">
            <?php _e( '📊 Порівняти плагіни', 'wp-security-dss' ); ?>
        </a>
        <a href="<?php echo admin_url( 'admin.php?page=wpdss-recommendations' ); ?>" class="button button-primary button-large">
            <?php _e( '🎯 DSS рекомендація', 'wp-security-dss' ); ?>
        </a>
        <a href="<?php echo admin_url( 'admin.php?page=wpdss-database' ); ?>" class="button button-secondary button-large">
            <?php _e( '🗄 База результатів', 'wp-security-dss' ); ?>
        </a>
    </div>
</div>
