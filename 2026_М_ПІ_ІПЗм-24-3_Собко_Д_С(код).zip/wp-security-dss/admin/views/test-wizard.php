<?php
/**
 * Майстер тестування нового плагіну
 *
 * @package WP_Security_DSS
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$db = new WPDSS_Database();
$prefix = $db->get_prefix();
$vulnerabilities = $wpdb->get_results( "SELECT * FROM {$prefix}vulnerabilities ORDER BY code" );
?>

<div class="wrap wpdss-wrap">
    <div class="wpdss-header">
        <h1 class="wpdss-title">
            <span class="dashicons dashicons-plus-alt"></span>
            <?php _e( 'Майстер тестування нового плагіну', 'wp-security-dss' ); ?>
        </h1>
        <p class="wpdss-subtitle">
            <?php _e( 'Додайте новий захисний плагін до бази даних через стандартну процедуру', 'wp-security-dss' ); ?>
        </p>
    </div>

    <!-- Прогрес майстра -->
    <div class="wpdss-wizard-progress">
        <div class="wpdss-step active" data-step="1">
            <div class="wpdss-step-circle">1</div>
            <div class="wpdss-step-label"><?php _e( 'Інформація', 'wp-security-dss' ); ?></div>
        </div>
        <div class="wpdss-step" data-step="2">
            <div class="wpdss-step-circle">2</div>
            <div class="wpdss-step-label"><?php _e( 'Сканування', 'wp-security-dss' ); ?></div>
        </div>
        <div class="wpdss-step" data-step="3">
            <div class="wpdss-step-circle">3</div>
            <div class="wpdss-step-label"><?php _e( 'Атаки', 'wp-security-dss' ); ?></div>
        </div>
        <div class="wpdss-step" data-step="4">
            <div class="wpdss-step-circle">4</div>
            <div class="wpdss-step-label"><?php _e( 'Продуктивність', 'wp-security-dss' ); ?></div>
        </div>
        <div class="wpdss-step" data-step="5">
            <div class="wpdss-step-circle">5</div>
            <div class="wpdss-step-label"><?php _e( 'Збереження', 'wp-security-dss' ); ?></div>
        </div>
    </div>

    <!-- Етап 1: Інформація -->
    <div class="wpdss-wizard-content" id="step-1">
        <div class="wpdss-card">
            <h2><?php _e( 'Етап 1: Інформація про плагін', 'wp-security-dss' ); ?></h2>
            <table class="wpdss-form-table">
                <tr>
                    <th><label for="p_code"><?php _e( 'Код плагіну', 'wp-security-dss' ); ?></label></th>
                    <td>
                        <input type="text" id="p_code" placeholder="A6" maxlength="10" required>
                        <p class="description"><?php _e( 'Унікальний ідентифікатор (наприклад A6, A7)', 'wp-security-dss' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="p_name"><?php _e( 'Назва плагіну', 'wp-security-dss' ); ?></label></th>
                    <td>
                        <input type="text" id="p_name" placeholder="Solid Security" required>
                    </td>
                </tr>
                <tr>
                    <th><label for="p_version"><?php _e( 'Версія', 'wp-security-dss' ); ?></label></th>
                    <td>
                        <input type="text" id="p_version" placeholder="11.0.0" required>
                    </td>
                </tr>
                <tr>
                    <th><label for="p_arch"><?php _e( 'Архітектура', 'wp-security-dss' ); ?></label></th>
                    <td>
                        <select id="p_arch">
                            <option value="Local CVE Database">Local CVE Database (як Wordfence)</option>
                            <option value="Local Integrity Check">Local Integrity Check (як Sucuri Free)</option>
                            <option value="Cloud Patchstack API">Cloud Patchstack API (як Kadence)</option>
                            <option value="Cloud Scanner">Cloud Scanner (як MalCare)</option>
                            <option value="Hybrid">Hybrid (Local + Cloud)</option>
                        </select>
                    </td>
                </tr>
            </table>
            <p>
                <button class="button button-primary wpdss-next-btn" data-next="2">
                    <?php _e( 'Далі →', 'wp-security-dss' ); ?>
                </button>
            </p>
        </div>
    </div>

    <!-- Етап 2: Сканування -->
    <div class="wpdss-wizard-content" id="step-2" style="display:none;">
        <div class="wpdss-card">
            <h2><?php _e( 'Етап 2: Пасивне сканування (Recall)', 'wp-security-dss' ); ?></h2>
            <p><?php _e( 'Запустіть сканер плагіну і відмітьте, які з 12 вразливих плагінів він виявив:', 'wp-security-dss' ); ?></p>

            <table class="wpdss-table wpdss-table-checklist">
                <thead>
                    <tr>
                        <th width="60"><?php _e( 'Код', 'wp-security-dss' ); ?></th>
                        <th><?php _e( 'Плагін', 'wp-security-dss' ); ?></th>
                        <th><?php _e( 'CVE', 'wp-security-dss' ); ?></th>
                        <th><?php _e( 'Клас атаки', 'wp-security-dss' ); ?></th>
                        <th width="120"><?php _e( 'Виявлено?', 'wp-security-dss' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $vulnerabilities as $v ) : ?>
                    <tr>
                        <td><strong><?php echo esc_html( $v->code ); ?></strong></td>
                        <td><?php echo esc_html( $v->name ); ?> v<?php echo esc_html( $v->version ); ?></td>
                        <td><small><?php echo esc_html( $v->cve ); ?></small></td>
                        <td><small><?php echo esc_html( $v->attack_class ); ?></small></td>
                        <td>
                            <label class="wpdss-toggle">
                                <input type="checkbox" class="wpdss-detect-check" data-code="<?php echo esc_attr( $v->code ); ?>">
                                <span class="wpdss-toggle-slider"></span>
                            </label>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="wpdss-progress-info">
                <?php _e( 'Виявлено:', 'wp-security-dss' ); ?>
                <strong id="detected_count">0</strong> / 12
                — Recall = <strong id="recall_value">0%</strong>
            </div>

            <p>
                <button class="button wpdss-prev-btn" data-prev="1">← <?php _e( 'Назад', 'wp-security-dss' ); ?></button>
                <button class="button button-primary wpdss-next-btn" data-next="3"><?php _e( 'Далі →', 'wp-security-dss' ); ?></button>
            </p>
        </div>
    </div>

    <!-- Етап 3: Атаки -->
    <div class="wpdss-wizard-content" id="step-3" style="display:none;">
        <div class="wpdss-card">
            <h2><?php _e( 'Етап 3: Активні атаки (Block Rate)', 'wp-security-dss' ); ?></h2>
            <p><?php _e( 'Проведіть 6 типових атак і відмітьте результат:', 'wp-security-dss' ); ?></p>

            <table class="wpdss-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php _e( 'Атака', 'wp-security-dss' ); ?></th>
                        <th><?php _e( 'Команда / Дія', 'wp-security-dss' ); ?></th>
                        <th width="150"><?php _e( 'Результат', 'wp-security-dss' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $attacks = array(
                    array( 'XSS Stored',          '<script>alert("XSS")</script> в коментарі' ),
                    array( 'SQL Injection',       "?s=' OR '1'='1" ),
                    array( 'Brute Force',         'curl -X POST wp-login.php × 15' ),
                    array( 'File Upload / RCE',   'curl POST /wp-json/wp/v2/media' ),
                    array( 'Parameter Tampering', '?add-to-cart=97&quantity=-1' ),
                    array( 'CSRF',                'HTML форма з add-to-cart' ),
                );
                foreach ( $attacks as $i => $a ) :
                ?>
                <tr>
                    <td><strong><?php echo $i + 1; ?></strong></td>
                    <td><?php echo esc_html( $a[0] ); ?></td>
                    <td><code><?php echo esc_html( $a[1] ); ?></code></td>
                    <td>
                        <select class="wpdss-attack-result" data-type="<?php echo esc_attr( $a[0] ); ?>">
                            <option value="Pass">❌ Pass (не блоковано)</option>
                            <option value="Block">✅ Block (заблоковано)</option>
                            <option value="Warn">⚠️ Warn (попередження)</option>
                        </select>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div class="wpdss-progress-info">
                <?php _e( 'Заблоковано:', 'wp-security-dss' ); ?>
                <strong id="blocks_count">0</strong> / 6
                — Block Rate = <strong id="block_rate_value">0%</strong>
            </div>

            <p>
                <button class="button wpdss-prev-btn" data-prev="2">← <?php _e( 'Назад', 'wp-security-dss' ); ?></button>
                <button class="button button-primary wpdss-next-btn" data-next="4"><?php _e( 'Далі →', 'wp-security-dss' ); ?></button>
            </p>
        </div>
    </div>

    <!-- Етап 4: Продуктивність -->
    <div class="wpdss-wizard-content" id="step-4" style="display:none;">
        <div class="wpdss-card">
            <h2><?php _e( 'Етап 4: Метрики продуктивності', 'wp-security-dss' ); ?></h2>
            <p><?php _e( 'Замірте через Activity Monitor (або htop) показники до і під час сканування:', 'wp-security-dss' ); ?></p>

            <table class="wpdss-form-table">
                <tr>
                    <th><label for="cpu_base">CPU базовий (%)</label></th>
                    <td><input type="number" id="cpu_base" step="0.1" value="5.0" min="0" max="100"></td>
                </tr>
                <tr>
                    <th><label for="cpu_load">CPU при скануванні (%)</label></th>
                    <td><input type="number" id="cpu_load" step="0.1" value="10.0" min="0" max="100"></td>
                </tr>
                <tr>
                    <th><label for="ram_base">RAM базовий (MB)</label></th>
                    <td><input type="number" id="ram_base" value="40" min="0"></td>
                </tr>
                <tr>
                    <th><label for="ram_load">RAM при скануванні (MB)</label></th>
                    <td><input type="number" id="ram_load" value="100" min="0"></td>
                </tr>
            </table>

            <p>
                <button class="button wpdss-prev-btn" data-prev="3">← <?php _e( 'Назад', 'wp-security-dss' ); ?></button>
                <button class="button button-primary wpdss-next-btn" data-next="5"><?php _e( 'Далі →', 'wp-security-dss' ); ?></button>
            </p>
        </div>
    </div>

    <!-- Етап 5: Збереження -->
    <div class="wpdss-wizard-content" id="step-5" style="display:none;">
        <div class="wpdss-card">
            <h2><?php _e( 'Етап 5: Підтвердження та збереження', 'wp-security-dss' ); ?></h2>
            <div id="summary_preview"></div>

            <p>
                <button class="button wpdss-prev-btn" data-prev="4">← <?php _e( 'Назад', 'wp-security-dss' ); ?></button>
                <button class="button button-primary button-hero" id="save_test_btn">
                    <span class="dashicons dashicons-saved"></span>
                    <?php _e( 'Зберегти результати тесту', 'wp-security-dss' ); ?>
                </button>
            </p>

            <div id="save_result" style="display:none;"></div>
        </div>
    </div>
</div>
