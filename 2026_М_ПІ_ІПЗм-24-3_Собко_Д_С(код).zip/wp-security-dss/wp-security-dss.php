<?php
/**
 * Plugin Name:       WP Security DSS
 * Plugin URI:        https://github.com/dariadev/wp-security-dss
 * Description:       Система підтримки прийняття рішень (DSS) для вибору оптимального плагіну безпеки WordPress. 11 плагінів × 51 уразливих × 6 типів атак. Магістерська науково-дослідницька робота.
 * Version:           2.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Собко Дарія (ХНУРЕ, ІПЗм-24-3)
 * Author URI:        https://nure.ua
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-security-dss
 * Domain Path:       /languages
 *
 * @package WP_Security_DSS
 */

// Захист від прямого доступу
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Константи плагіну
define( 'WPDSS_VERSION', '2.0.0' );
define( 'WPDSS_PLUGIN_FILE', __FILE__ );
define( 'WPDSS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPDSS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPDSS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Підключення основних класів
require_once WPDSS_PLUGIN_DIR . 'includes/class-dss-database.php';
require_once WPDSS_PLUGIN_DIR . 'includes/class-dss-detector.php';
require_once WPDSS_PLUGIN_DIR . 'includes/class-dss-calculator.php';
require_once WPDSS_PLUGIN_DIR . 'includes/class-dss-recommendation.php';
require_once WPDSS_PLUGIN_DIR . 'includes/class-dss-admin.php';

/**
 * Головний клас плагіну
 */
class WP_Security_DSS {

    /**
     * Єдиний екземпляр класу (Singleton)
     */
    private static $instance = null;

    /**
     * Отримати єдиний екземпляр
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Конструктор
     */
    private function __construct() {
        // Активація / деактивація
        register_activation_hook( WPDSS_PLUGIN_FILE, array( $this, 'activate' ) );
        register_deactivation_hook( WPDSS_PLUGIN_FILE, array( $this, 'deactivate' ) );

        // Ініціалізація після завантаження WP
        add_action( 'plugins_loaded', array( $this, 'init' ) );
    }

    /**
     * Активація плагіну: створення таблиць БД, наповнення даними
     */
    public function activate() {
        // Створюємо таблиці БД
        $db = new WPDSS_Database();
        $db->create_tables();

        // Наповнюємо базою із 11 плагінів безпеки та 51 уразливим плагіном
        $db->seed_initial_data();

        // Зберігаємо версію в опціях
        update_option( 'wpdss_version', WPDSS_VERSION );
        update_option( 'wpdss_activated_at', current_time( 'mysql' ) );

        flush_rewrite_rules();
    }

    /**
     * Деактивація плагіну
     */
    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Ініціалізація
     */
    public function init() {
        // Завантажуємо переклади
        load_plugin_textdomain( 'wp-security-dss', false, dirname( WPDSS_PLUGIN_BASENAME ) . '/languages' );

        // Адмін-інтерфейс (тільки в адмінці)
        if ( is_admin() ) {
            new WPDSS_Admin();
        }
    }
}

// Запускаємо плагін
WP_Security_DSS::get_instance();
